import { getCompletePageWithIframeContent } from './jslib/get_complete_page_with_iframe_content.js'
import { getBrowserInfo } from './jslib/get_browser_version.js'
import { executePlaywrightPageMethod_lib, convertToBrowserLocator_lib, executePlaywrightJS_lib } from './jslib/playwright_page_helper.js'
// import { CompareImagesWithPixelmatch1 } from './jslib/pixelmatch.js'
import { startNetworkMonitoring_lib, logNetworkLogs_lib } from './jslib/network_logs.js'
export const getCompletePageWithIframes = getCompletePageWithIframeContent
export const getBrowserInformation = getBrowserInfo
export const executePlaywrightPageMethod = executePlaywrightPageMethod_lib
export const convertToBrowserLocator = convertToBrowserLocator_lib
// export const compareImagesWithPixelmatch = CompareImagesWithPixelmatch1
// export const logNetworkTraffic = monitorBrowserActivities
export const startNetworkMonitoring = startNetworkMonitoring_lib
export const logNetworkLogs = logNetworkLogs_lib
export const executePlaywrightJS = executePlaywrightJS_lib