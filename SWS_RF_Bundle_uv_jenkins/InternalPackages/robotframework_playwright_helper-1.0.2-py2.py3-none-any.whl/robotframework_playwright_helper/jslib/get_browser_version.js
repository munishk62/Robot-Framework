async function getBrowserInfo(page) {
    return await page.evaluate(() => {
        const userAgent = navigator.userAgent;
        let browserName = "Unknown";
        let fullVersion = "Unknown";

        // RegEx for parsing to determine browser name and version
        if (userAgent.includes("Chrome")) {
            browserName = "Chrome";
            fullVersion = userAgent.match(/Chrome\/([\d.]+)/)[1];
        }
        else if (userAgent.includes("Firefox")) {
            browserName = "Firefox";
            fullVersion = userAgent.match(/Firefox\/([\d.]+)/)[1];
        } 
        else if (userAgent.includes("applewebkit")) {
            // Identify as WebKit if "applewebkit" is present but not "chrome" (handled automatically by the if else condition)
            browserName = "WebKit";
            const match = userAgent.match(/applewebkit\/([\d.]+)/);
        }

        return "" + browserName + ", Version: " + fullVersion;
    });
}

exports.getBrowserInfo = getBrowserInfo;