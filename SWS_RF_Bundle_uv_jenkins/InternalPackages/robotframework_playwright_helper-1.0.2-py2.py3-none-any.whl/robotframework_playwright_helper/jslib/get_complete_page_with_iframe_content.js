// Asynchronous function to retrieve the entire page content, including iframes
async function getCompletePageWithIframeContent(page) {
    // Wait for the page to be fully loaded
    await page.waitForLoadState('load');

    // Get the main page's HTML content
    const mainPageContent = await page.content();
    let modifiedContent = mainPageContent;

    // Inner function to recursively extract content from iframes
    async function extractFramesContent(frame) {
        try {
            // Wait for the iframe's content to load, with a timeout of 20 seconds
            await frame.waitForLoadState('load', { timeout: 20000 });

            // Get the iframe element from the frame
            const frameElement = await frame.frameElement();

            // Evaluate the frame's content and construct its HTML, including the DOCTYPE
            const frameHtml = await frame.evaluate(() => {
                const doctype = Array.from(document.childNodes)
                    .filter(node => node.nodeType === Node.DOCUMENT_TYPE_NODE)
                    .map(dt => `<!DOCTYPE ${dt.name}>`)
                    .join('');
                return doctype + document.documentElement.outerHTML;
            });

            // Get the outer HTML of the iframe tag
            const frameTagHtml = await frameElement.evaluate(node => node.outerHTML);

            // Replace the closing iframe tag with the iframe's content wrapped in comments
            const newIframeHtml = frameTagHtml.replace(
                '</iframe>',
                `<!-- Begin iframe content -->
                ${frameHtml}
                <!-- End iframe content --></iframe>`
            );

            // Update the main page content with the modified iframe content
            modifiedContent = modifiedContent.replace(frameTagHtml, newIframeHtml);
        } 
        catch (e) {
            // Log a warning if the iframe content cannot be accessed
            console.warn('Cannot access iframe content');
        }

        // Recursively handle any child frames within the current frame
        const childFrames = frame.childFrames();
        for (const childFrame of childFrames) {
            await extractFramesContent(childFrame);
        }
    }
    
    // Locate all lazy-loaded iframes on the page
    const iframes = await page.$$('iframe[loading="lazy"]');
    for (const iframe of iframes) {
        // Scroll each iframe into view to ensure it gets loaded
        await page.evaluate(iframe => {
            iframe.scrollIntoView();
        }, iframe);
        // Wait for 2 seconds to allow the iframe to load
        await page.waitForTimeout(2000);
    }

    // Get all frames on the page, including main and child frames
    const frames = page.frames();
    for (const frame of frames) {
        // Skip the main frame as we only want to process iframes
        if (frame === page.mainFrame())
            continue;
        // Extract content from each iframe
        await extractFramesContent(frame);
    }

    // Return the modified page content with iframes' content included
    return modifiedContent;
}

// Add a documentation string to the function for Robot Framework
getCompletePageWithIframeContent.rfdoc = "Returns the entire page HTML with iframes' content included between the tags.";

// Export the function for use in other modules
exports.__esModule = true;
exports.getCompletePageWithIframeContent = getCompletePageWithIframeContent;
