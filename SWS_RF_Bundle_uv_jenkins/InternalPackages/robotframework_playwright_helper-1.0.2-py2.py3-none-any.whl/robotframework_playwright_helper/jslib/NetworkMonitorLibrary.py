from Browser import Browser
import json

class NetworkMonitor:
    def __init__(self):
        self.browser = Browser()
        self.network_logs = []

    def start_network_monitoring(self):
        context = self.browser.get_browser_context()
        page = context.new_page()
        
        def log_request(request):
            self.network_logs.append({
                'url': request.url,
                'method': request.method,
                'headers': request.headers,
                'postData': request.post_data,
                'resourceType': request.resource_type
            })

        # Attach request listener to the page
        page.on('request', log_request)

    def print_network_logs(self):
        for log in self.network_logs:
            print(json.dumps(log, indent=2))

# Create an instance of the NetworkMonitor
network_monitor = NetworkMonitor()

def start_network_monitoring():
    network_monitor.start_network_monitoring()

def print_network_logs():
    network_monitor.print_network_logs()
