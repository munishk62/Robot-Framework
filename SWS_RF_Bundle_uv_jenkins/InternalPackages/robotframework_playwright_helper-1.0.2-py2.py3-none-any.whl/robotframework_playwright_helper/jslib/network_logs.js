const networkLogs = {
    requests: [],
    responses: []
};

async function startNetworkMonitoring(page) {
    if (!page || typeof page.on !== 'function') {
        throw new Error('Invalid page object passed to startNetworkMonitoring.');
    }

    console.log('Starting network monitoring...');

    networkLogs.requests = [];
    networkLogs.responses = [];

    page.on('request', request => {
        const requestData = {
            url: request.url(),
            method: request.method(),
            headers: request.headers(),
            time: new Date().toISOString()
        };
        networkLogs.requests.push(requestData);
        // console.log('Captured Request:', requestData);
    });

    page.on('response', async response => {
        try {
            // Capture headers, URL, and status code
            const responseData = {
                url: response.url(),
                status: response.status(),
                statusText: response.statusText(),  // Add status text for better context
                headers: response.headers(),
                time: new Date().toISOString()
            };
            networkLogs.responses.push(responseData);
        } catch (error) {
            Pass;
            // console.warn('Failed to read response body:', error);
        }
    });

    // console.log('Network monitoring started.');
}

function logNetworkLogs() {
    return 'Logging network logs...' +
        ' Network Requests: ' + JSON.stringify(networkLogs.requests, null, 2) +
        ' Network Responses: ' + JSON.stringify(networkLogs.responses, null, 2) +
        ' Finished logging network logs.';
}

// Export functions for use in Robot Framework
exports.__esModule = true;
exports.startNetworkMonitoring_lib = startNetworkMonitoring;
exports.logNetworkLogs_lib = logNetworkLogs;
