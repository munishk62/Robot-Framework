# from SWSListener.SWSLogger import sws_logger
# import subprocess
# import time
# import os
# import console_ctrl


# def start_android_device_screen_recorder(device_sn, file_path, file_name):
#     complete_video_file_path = os.path.normpath(os.path.join(file_path, str(file_name) + "_" + str(device_sn)) + ".mp4")
#     cmd_as_string = "scrcpy -s {} --no-display --record={}".format(device_sn, complete_video_file_path)
#     info = subprocess.STARTUPINFO()
#     info.dwFlags = subprocess.STARTF_USESHOWWINDOW
#     info.wShowWindow = 0
#     p = subprocess.Popen(cmd_as_string, creationflags=subprocess.CREATE_NEW_CONSOLE, startupinfo=info)
#     sws_logger.debug("Starting Video Recording : {} - {}".format(cmd_as_string, p.pid))
#     return p, complete_video_file_path


# def stop_android_device_screen_recorder(process_name):
#     pid = process_name.pid
#     console_ctrl.send_ctrl_c(pid)
#     time.sleep(1)
#     sws_logger.debug("Video Recording Stopped : {}".format(pid))


# def start_android_logcat_capture(device_sn, file_path, file_name):
#     complete_logcat_file_path = os.path.normpath(os.path.join(
#         file_path, str(file_name) + "_" + str(device_sn)) + ".txt")
#     cmd_as_string = "adb -s {} logcat -v time > {}".format(device_sn, complete_logcat_file_path)
#     info = subprocess.STARTUPINFO()
#     info.dwFlags = subprocess.STARTF_USESHOWWINDOW
#     info.wShowWindow = 0
#     p = subprocess.Popen(cmd_as_string, creationflags=subprocess.CREATE_NEW_CONSOLE, startupinfo=info, shell=True)
#     sws_logger.debug("Starting logcat Collection : {} - {}".format(cmd_as_string, p.pid))
#     return p, complete_logcat_file_path


# def stop_android_logcat_capture(process_name):
#     pid = process_name.pid
#     console_ctrl.send_ctrl_c(pid)
#     time.sleep(1)
#     sws_logger.debug("Logcat collection Stopped : {}".format(pid))


# # For testing Video recording
# start_record_process, video_file_path = start_android_device_screen_recorder("230075247E0136", os.getcwd(), "SWS-123")
# print(video_file_path)
# time.sleep(30)
# stop_android_device_screen_recorder(start_record_process)


# # For testing capture logcat
# start_lg_process, lg_file_path = start_android_logcat_capture("211475225D0028", os.getcwd(), "SWS-123")
# print(lg_file_path)
# time.sleep(10)
# stop_android_logcat_capture(start_lg_process)
