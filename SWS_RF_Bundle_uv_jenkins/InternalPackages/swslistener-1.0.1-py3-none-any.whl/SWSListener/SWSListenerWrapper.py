import glob
import sys
import os
import json
import threading
import shutil
import yaml
import SWSListener.SWSLogger

from SWSListener.SWSLogger import sws_logger
from SWSListener.SWSLogger import color_print
from robot.libraries.BuiltIn import BuiltIn
from yaml.loader import SafeLoader
from . import SWSListener_Util

is_test_ray_set_correct = False
try:
    from Jira_Test_Ray_Helper import Jira_Test_Ray
    is_test_ray_set_correct = True
except Exception as e:
    sws_logger.error(e)

EXECUTION_LOGS_ROOT_DIR = r"C:\LOGS"

FAILURE_EXPECTED_KEYWORD_LIST = ['Run Keyword And Expect Error',
                                 'Run Keyword And Return Status',
                                 'Run Keyword And Ignore Error']


class SWSListenerWrapper:
    ROBOT_LISTENER_API_VERSION = 2

    def __init__(self, test_plan_id=None, test_cycle_name=None):
        self.high_level_keyword = None
        self.robot_builtin = BuiltIn()
        self.total_test_cases = 0
        self.pending_test_cases = 0
        self.passed_test_cases = 0
        self.failed_test_cases = 0
        self.current_test_case_count = 0
        self.current_test_case_id = ""
        self.is_device_screenshot_captured_on_tc_failure = False
        self.is_setup_failure_seen = False
        self.suite_logs_root_folder = ""
        self.test_case_logs_folder = ""
        self.test_case_logs_folder_list = []
        self.number_of_devices = 0
        self.android_screen_recorder_list = []
        self.android_logcat_list = []
        self.listener_config_file_name = "Config_RobotListener.yaml"
        self.listener_config_file_path = ""
        self.is_listener_config_file_found = False
        self.can_next_keyword_printed = True
        self.listener_config_dict = {'Collect_Logcat': False,
                                     'Capture_DUT_Video': False,
                                     'Result_To_File': False,
                                     'Update_Results_In_TRS': False,
                                     'Show_Executing_keyword': False,
                                     'Collect_PTT_PRO_logs': False,
                                     'Collect_logs_on_Pass': False,
                                     'PC_Log_Directory': '{}'.format(EXECUTION_LOGS_ROOT_DIR)}
        self.test_result_dict = {}
        self.update_result_to_test_ray = False
        self.update_result_to_test_ray_thread_list = []
        self.test_ray_test_plan_id = test_plan_id
        self.test_ray_test_cycle_name = test_cycle_name
        if test_plan_id is not None and test_cycle_name is not None:
            self.update_result_to_test_ray = True

    def start_suite(self, name, attrs):
        """
        Performs the following action
        1. Create Suite log folder

        """
        try:
            self.total_test_cases = attrs["totaltests"]
            self.pending_test_cases = attrs["totaltests"]
            sws_logger.info("Starting_Suite : {}  : {}".format(name, self.total_test_cases))
            sws_logger.debug("Starting_Suite_Location : {}  : {}".format(name, attrs["source"]))
            source_folder, source_file = os.path.split(attrs["source"])
            configuration_file_path = os.path.normpath(os.path.join(source_folder, self.listener_config_file_name))
            sws_logger.debug("Checking Config file in : {}".format(configuration_file_path))
            if os.path.isfile(configuration_file_path):
                self.is_listener_config_file_found = True
                self.listener_config_file_path = configuration_file_path
            else:
                configuration_file_path = (
                    os.path.normpath(os.path.join(os.path.split(source_folder)[0], self.listener_config_file_name)))
                sws_logger.debug("Checking Config file in : {}".format(configuration_file_path))
                if os.path.isfile(configuration_file_path):
                    self.is_listener_config_file_found = True
                    self.listener_config_file_path = os.path.normpath(os.path.join(configuration_file_path))
                else:
                    sws_logger.warn("Listener Configuration file not found")
            if self.is_listener_config_file_found:
                sws_logger.info("Reading Listener Configuration : {}".format(self.listener_config_file_path))
                safe_path = os.path.abspath(os.path.normpath(self.listener_config_file_path))
                with open(safe_path) as f:
                    config_from_file = yaml.load(f, Loader=SafeLoader)
                    for config in config_from_file:
                        self.listener_config_dict[config] = config_from_file[config]
                for config in self.listener_config_dict:
                    sws_logger.debug("{} : {}".format(config, self.listener_config_dict[config]))
            self.suite_logs_root_folder = SWSListener_Util.create_suite_logs_root_folder(EXECUTION_LOGS_ROOT_DIR, name)
            SWSListener_Util.set_pw_browser_log_folder(self.suite_logs_root_folder)
            sws_logger.debug("Suite Log Folder name : {}".format(self.suite_logs_root_folder))

            self.test_ray_test_plan_id = self.robot_builtin.get_variable_value("${TEST_RAY_TEST_PLAN_ID}")
            self.test_ray_test_cycle_name = self.robot_builtin.get_variable_value("${TEST_RAY_TEST_CYCLE_NAME}")
            if self.test_ray_test_plan_id is not None and self.test_ray_test_cycle_name is not None:
                self.update_result_to_test_ray = True
            if self.update_result_to_test_ray:
                if not is_test_ray_set_correct:
                    sws_logger.error("Jira Test Ray Module is not set correctly for result Update.")
                    sys.exit(-1)

            sws_logger.debug("Test Ray Result to be updated : {}".format(self.update_result_to_test_ray))
            sws_logger.debug("Test Ray Result Test plan id : {}".format(self.test_ray_test_plan_id))
            sws_logger.debug("Test Ray Result Test cycle name : {}".format(self.test_ray_test_cycle_name))

            device_count_from_robot_script = self.robot_builtin.get_variable_value("${Number_Of_Devices}")
            sws_logger.debug("Device Count From Number_Of_Devices: {}".format(device_count_from_robot_script))
            if device_count_from_robot_script is not None:
                self.number_of_devices = device_count_from_robot_script
            sws_logger.debug("Device Count : {}".format(self.number_of_devices))

            # Start Video Recording in all attached devices for suite setup
            if int(self.number_of_devices) > 0 and self.listener_config_dict["Capture_DUT_Video"]:
                self.android_screen_recorder_list = []
                self.android_screen_recorder_list = SWSListener_Util.start_video_recording_on_all_devices(
                    self.number_of_devices, self.suite_logs_root_folder,
                    "Suite_setup")

            # Start Logcat capture in all attached devices for suite setup
            if int(self.number_of_devices) > 0 and self.listener_config_dict["Collect_Logcat"]:
                self.android_logcat_list = []
                self.android_logcat_list = SWSListener_Util.start_logcat_capture_on_all_devices(
                    self.number_of_devices, self.suite_logs_root_folder,
                    "Suite_setup")

        except Exception as e:
            sws_logger.exception(e)

    def start_test(self, name, attrs):
        """
        Performs the following action
        1. Create Test case log folder under Suite log folder

        """
        try:
            self.can_next_keyword_printed = True
            suite_status = self.robot_builtin.get_variable_value("${SUITE STATUS}")
            sws_logger.debug(f"suite status : {suite_status}")

            # Stop Video Recording in all attached devices for suite setup
            if int(self.number_of_devices) > 0 and self.listener_config_dict["Capture_DUT_Video"]:
                SWSListener_Util.stop_video_recording_on_all_devices(self.android_screen_recorder_list,
                                                                     suite_status,
                                                                     self.listener_config_dict["Collect_logs_on_Pass"])

            # Stop Logcat capture in all attached devices for suite setup
            if int(self.number_of_devices) > 0 and self.listener_config_dict["Collect_Logcat"]:
                SWSListener_Util.stop_logcat_capture_on_all_devices(self.android_logcat_list, suite_status,
                                                                    self.listener_config_dict["Collect_logs_on_Pass"])

            self.is_device_screenshot_captured_on_tc_failure = False
            self.current_test_case_count += 1
            sws_logger.debug("===============================================")
            print("\n")
            test_case_id = str(name).split(" ")[0]
            print_message = "Starting_Test : {} - {} out of {}".format(test_case_id, self.current_test_case_count,
                                                                       self.total_test_cases)
            color_print(print_message)
            sws_logger.debug(print_message)
            self.test_case_logs_folder = SWSListener_Util.create_test_case_logs_folder(self.suite_logs_root_folder,
                                                                                       test_case_id)
            sws_logger.debug(self.test_case_logs_folder)
            self.test_case_logs_folder_list.append(self.test_case_logs_folder)
            SWSListener_Util.set_pw_browser_log_folder(self.test_case_logs_folder)

            if not self.is_setup_failure_seen:

                # Start Video Recording in all attached devices for test case
                if int(self.number_of_devices) > 0 and self.listener_config_dict["Capture_DUT_Video"]:
                    self.android_screen_recorder_list = []
                    self.android_screen_recorder_list = SWSListener_Util.start_video_recording_on_all_devices(
                        self.number_of_devices, self.test_case_logs_folder,
                        test_case_id)

                # Start Logcat capture in all attached devices for test case
                if int(self.number_of_devices) > 0 and self.listener_config_dict["Collect_Logcat"]:
                    self.android_logcat_list = []
                    self.android_logcat_list = SWSListener_Util.start_logcat_capture_on_all_devices(
                        self.number_of_devices, self.test_case_logs_folder,
                        test_case_id)

        except Exception as e:
            sws_logger.exception(e)

    def start_keyword(self, name, attrs):
        try:
            unresolved_keyword_and_variable = "Start_Keyword Unresolved args : {} {}".format(name, attrs["args"])
            sws_logger.debug(unresolved_keyword_and_variable)
            # sws_logger.debug("Keyword_Type : {}".format(attrs["type"]))
            message_to_log = "Start_Keyword : {} ".format(name)

            if self.can_next_keyword_printed:
                self.high_level_keyword = name
                print("{} : {} {}".format(attrs["starttime"], name, attrs["args"]))
                self.can_next_keyword_printed = False

            if len(attrs["args"]) > 0:
                resolved_variable_list = []
                for robot_variable in attrs["args"]:
                    if "{" in robot_variable and "}" in robot_variable:
                        sws_logger.debug("resolving robot variable : {}".format(robot_variable))
                        try:
                            resolved_variable_list.append(str(self.robot_builtin.get_variable_value(robot_variable)))
                        except Exception as e:
                            resolved_variable_list.append(robot_variable)
                            sws_logger.debug("exception resolving robot variable : {}".format(e))
                    # else:
                    #     sws_logger.debug("Not robot variable : {}".format(robot_variable))
                resolved_keyword_and_variable = "Start_Keyword : {} {}".format(name, resolved_variable_list)
                message_to_log = resolved_keyword_and_variable
            else:
                if len(name) > 0:
                    message_to_log = "Start_Keyword : {}".format(name)
            if self.listener_config_dict["Show_Executing_keyword"]:
                sws_logger.info(message_to_log)
            else:
                sws_logger.debug(message_to_log)
        except Exception as e:
            sws_logger.exception(e)

    def end_keyword(self, name, attrs):
        try:
            sws_logger.debug("End_Keyword : {} , Status : {}".format(name, attrs['status']))

            if self.high_level_keyword == name:
                self.can_next_keyword_printed = True

            # if attrs['status'] == "FAIL" and name not in FAILURE_EXPECTED_KEYWORD_LIST:
            #     if not self.is_device_screenshot_captured_on_tc_failure:
            #         sws_logger.debug("Need to Capture Device Screenshot on Keyword Failure")
            #         number_of_devices = self.number_of_devices
            #         sws_logger.debug("Device Count : {}".format(number_of_devices))
            #         SWSListener_Util.capture_all_device_screenshots(number_of_devices)
            #         self.is_device_screenshot_captured_on_tc_failure = True
            #     else:
            #         sws_logger.debug("Device Screenshot already captured on Keyword Failure")
        except Exception as e:
            sws_logger.exception(e)

    def end_test(self, name, attrs):
        try:
            sws_logger.debug("Ending_Test : {}".format(name))
            test_case_id = str(name).split(" ")[0]
            test_case_status = attrs["status"]
            sws_logger.debug("Test case Status : {}".format(test_case_status))
            sws_logger.debug("===============================================")
            self.pending_test_cases -= 1
            if test_case_status == "PASS":
                self.passed_test_cases += 1
            elif test_case_status == "FAIL":
                self.failed_test_cases += 1
            print("\n")
            current_test_case_result_dict = {"verdict": test_case_status,
                                             "comments": str(attrs["message"]),
                                             "version_info": self.robot_builtin.get_variable_value(
                                                 "${TRS_VERSION_INFO}")}

            if "Parent suite setup failed" in str(attrs["message"]):
                self.is_setup_failure_seen = True

            if self.update_result_to_test_ray:
                sws_logger.debug("Updating result in Test Ray")
                result_update_thread = threading.Thread(
                    target=Jira_Test_Ray.update_test_result_to_jira_test_ray_test_cycle,
                    args=(
                        self.test_ray_test_plan_id, self.test_ray_test_cycle_name, test_case_id, current_test_case_result_dict,))
                result_update_thread.name = test_case_id
                self.update_result_to_test_ray_thread_list.append(result_update_thread)
                result_update_thread.start()
            else:
                sws_logger.debug("Skipping Test Ray Result Update")
            self.test_result_dict[test_case_id] = current_test_case_result_dict
            print_message = ("Test Execution Stats >> Pass : {}, Fail : {},"
                             "  Pending : {}").format(self.passed_test_cases,
                                                      self.failed_test_cases,
                                                      self.pending_test_cases)
            color_print(print_message)
            sws_logger.debug(print_message)

            if not self.is_setup_failure_seen:

                if self.passed_test_cases == 1:

                    # Find all .mp4 files in the folder suite setup recorded video
                    mp4_files = glob.glob(os.path.normpath(os.path.join(self.suite_logs_root_folder, '*.mp4')))

                    # Delete each .mp4 file found
                    for file_path in mp4_files:
                        os.remove(file_path)
                        sws_logger.debug(f"File {file_path} has been deleted.")

                    safe_path = os.path.abspath(os.path.normpath(self.suite_logs_root_folder))
                    files = os.listdir(safe_path)

                    # Delete files that start with "Logcat_Suite_setup_" suite setup logcat logs
                    for file in files:
                        if file.startswith('Logcat_Suite_setup_'):
                            os.remove(os.path.normpath(os.path.join(self.suite_logs_root_folder, file)))
                            sws_logger.debug(f"File {file} has been deleted.")

                # Stop Video Recording in all attached devices
                if int(self.number_of_devices) > 0 and self.listener_config_dict["Capture_DUT_Video"]:
                    SWSListener_Util.stop_video_recording_on_all_devices(self.android_screen_recorder_list,
                                                                         test_case_status,
                                                                         self.listener_config_dict[
                                                                             "Collect_logs_on_Pass"])

                # Stop Logcat capture in all attached devices
                if int(self.number_of_devices) > 0 and self.listener_config_dict["Collect_Logcat"]:
                    SWSListener_Util.stop_logcat_capture_on_all_devices(self.android_logcat_list, test_case_status,
                                                                        self.listener_config_dict[
                                                                            "Collect_logs_on_Pass"])

                # Collect pro logs
                if test_case_status == "FAIL" or self.listener_config_dict["Collect_logs_on_Pass"]:
                    if int(self.number_of_devices) > 0 and self.listener_config_dict["Collect_PTT_PRO_logs"]:
                        SWSListener_Util.collect_ptt_pro_logs_on_all_devices(self.number_of_devices,
                                                                             self.test_case_logs_folder)
        except Exception as e:
            sws_logger.exception(e)

    def end_suite(self, name, attrs):
        try:
            if self.listener_config_dict["Result_To_File"]:
                result_json_file_path = os.path.normpath(os.path.join(self.suite_logs_root_folder, "Result.json"))
                sws_logger.debug("Writing Result to File : {}".format(result_json_file_path))
                with open(result_json_file_path, "w") as result_file:
                    json.dump(self.test_result_dict, result_file, indent=4)
        except Exception as e:
            sws_logger.exception(e)

    def log_file(self, path):
        try:
            safe_path = os.path.abspath(os.path.normpath(path))
            safe_dest = os.path.abspath(os.path.normpath(self.suite_logs_root_folder))
            shutil.copy(safe_path, safe_dest)
            pw_browser_screenshot_folder = os.path.abspath(os.path.normpath(os.path.join(os.path.split(safe_path)[0], 'browser')))
            if os.path.exists(pw_browser_screenshot_folder):
                shutil.copytree(pw_browser_screenshot_folder, os.path.join(safe_dest, "browser"))
        except Exception as e:
            sws_logger.exception(e)

    def output_file(self, path):
        try:
            safe_path = os.path.abspath(os.path.normpath(path))
            safe_dest = os.path.abspath(os.path.normpath(self.suite_logs_root_folder))
            shutil.copy(safe_path, safe_dest)
        except Exception as e:
            sws_logger.exception(e)

    def close(self):
        try:
            for thread in self.update_result_to_test_ray_thread_list:
                sws_logger.debug("Main    : before joining thread %s.", thread.name)
                thread.join()
                sws_logger.debug("Main    : thread %s done", thread.name)

            # Logic to delete empty log folders
            for folder_path in self.test_case_logs_folder_list:
                safe_path = os.path.abspath(os.path.normpath(folder_path))
                if os.path.exists(safe_path) and os.path.isdir(safe_path):
                    if not os.listdir(safe_path):
                        os.rmdir(safe_path)
                        sws_logger.debug(f"Folder {safe_path} has been deleted.")
                    else:
                        sws_logger.debug(f"Folder {safe_path} is not empty.")

        except Exception as e:
            sws_logger.exception(e)
        sws_logger.debug("Listener Execution Completed")
        log_file_location = os.path.abspath(os.path.normpath(SWSListener.SWSLogger.log_file_location))
        if os.path.exists(log_file_location):
            safe_source = os.path.abspath(os.path.normpath(log_file_location))
            safe_dest = os.path.abspath(os.path.normpath(self.suite_logs_root_folder))
            shutil.copy(safe_source, safe_dest)
