import os
import subprocess
import time
from datetime import datetime

from robot.libraries import BuiltIn
# from SWSListener import Android_Screen_Recorder
from SWSListener.SWSLogger import sws_logger

my_builtin = BuiltIn.BuiltIn()


# def capture_all_device_screenshots(no_of_devices):
#     no_of_devices = int(no_of_devices)
#     for i in range(1, no_of_devices + 1):
#         dut_name = "DUT" + str(i)
#         device_sn = my_builtin.get_variable_value("${" + dut_name + "}")
#         device_sn = str(device_sn)
#         capture_and_embed_screenshot_from_device(device_sn, dut_name)


# def capture_and_embed_screenshot_from_device(device_sn, dut_name="CURRENT_DUT"):
#     my_builtin.log("Device_SN:" + device_sn, level='INFO')
#     screenshot_folder = "/ExternalFiles/Android/VOIP/ScreenShots/"
#     if "_" in device_sn:
#         device_sn = device_sn.split("_")[1]
#         device_sn = str(device_sn).strip()
#     general_adb_obj = General_ADB.General_ADB(log_file_path=None, serial_number_of_device=device_sn)
#     exe_dir = my_builtin.get_variable_value("${EXECDIR}")
#     folder_path = exe_dir + screenshot_folder + str(device_sn).replace(".", "_").replace(":", "_")
#     capture_dut_screenshot(folder_path, dut_name, device_sn, general_adb_obj)
#     if os.path.exists(folder_path):
#         shutil.rmtree(folder_path)


# def embed_screen_shot_to_robot_log(image_path, dut_name, dut_id):
#     image_path = str(image_path)
#     image_path = str(image_path)
#     if image_path.endswith('.png') or image_path.endswith('.jpg'):
#         if os.path.exists(image_path):
#             data_uri = base64.b64encode(open(image_path, 'rb').read()).decode("utf-8", "ignore")
#             logger.info(
#                 '</td></tr><tr><td colspan="3">'
#                 '<img alt="screenshot" '
#                 f'src="data:image/png;base64,{data_uri}"/>',
#                 html=True
#             )


# def capture_dut_screenshot(folder_path, dut_name, device_sn, general_adb_obj):
#     if not os.path.exists(folder_path):
#         os.makedirs(folder_path)
#     image_file_path_device = "/data/local/tmp/DUT_ScreenShot.png"
#     image_file_path_pc = folder_path + '/DUT_ScreenShot_' + str(get_timestamp()) + ".png"
#     general_adb_obj.adb_save_screen(image_file_path_device, image_file_path_pc)
#     if os.path.exists(image_file_path_pc):
#         im = Image.open(image_file_path_pc)
#         width, height = im.size
#         new_width = int(width) // 3
#         new_height = int(height) // 3
#         im = im.resize((new_width, new_height), Image.Resampling.LANCZOS)
#         im.save(image_file_path_pc, quality=50, optimize=True)
#         embed_screen_shot_to_robot_log(image_file_path_pc, dut_name, device_sn)


def get_timestamp():
    time_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return str(time_stamp)


def create_suite_logs_root_folder(execution_logs_root_dir, suite_name):
    log_folder_path = os.path.normpath(
        os.path.join(execution_logs_root_dir, suite_name, suite_name + "_{}".format(get_timestamp()))
    )
    log_folder_path = log_folder_path.replace(" ", "_")
    if not os.path.exists(log_folder_path):
        validate_path(execution_logs_root_dir, log_folder_path)
        os.makedirs(log_folder_path)
    return log_folder_path


import os
import re


def is_valid_input(input_str):
    # only allow alphanumeric characters and underscores
    return bool(re.match("^[a-zA-Z0-9_]+$", input_str))


def create_test_case_logs_folder(suite_logs_folder, test_case_id):
    if is_valid_input(test_case_id):
        test_case_log_folder = os.path.normpath(os.path.join(suite_logs_folder, test_case_id))
        if not os.path.exists(test_case_log_folder):
            os.makedirs(test_case_log_folder)
        return test_case_log_folder
    else:
        # handle invalid input, e.g. raise an error or log a warning
        raise ValueError("Invalid test case ID")


# def start_video_recording_on_all_devices(no_of_devices, test_case_logs_folder, test_case_id):
#     no_of_devices = int(no_of_devices)
#     video_recording_list = []
#     for i in range(1, no_of_devices + 1):
#         dut_name = "DUT" + str(i)
#         device_sn = my_builtin.get_variable_value("${" + dut_name + "}")
#         device_sn = str(device_sn)
#         file_name = "{}_{}".format(test_case_id, dut_name)
#         start_record_process, video_file_path = Android_Screen_Recorder.start_android_device_screen_recorder(
#             device_sn, test_case_logs_folder, file_name
#         )
#         time.sleep(1)
#         video_recording_list.append((start_record_process, video_file_path))
#     sws_logger.debug("{}".format(video_recording_list))
#     return video_recording_list


# def stop_video_recording_on_all_devices(android_screen_recorder_list, test_case_status, retain_on_pass=False):
#     for video_process, video_file_name in android_screen_recorder_list:
#         Android_Screen_Recorder.stop_android_device_screen_recorder(video_process)
#         time.sleep(1)
#         if retain_on_pass:
#             return
#         else:
#             if os.path.exists(video_file_name) and test_case_status == "PASS":
#                 os.remove(video_file_name)


# def start_logcat_capture_on_all_devices(no_of_devices, test_case_logs_folder, test_case_id):
#     no_of_devices = int(no_of_devices)
#     logcat_capture_list = []
#     for i in range(1, no_of_devices + 1):
#         dut_name = "DUT" + str(i)
#         device_sn = my_builtin.get_variable_value("${" + dut_name + "}")
#         device_sn = str(device_sn)
#         file_name = "Logcat_{}_{}".format(test_case_id, dut_name)
#         start_record_process, video_file_path = Android_Screen_Recorder.start_android_logcat_capture(
#             device_sn, test_case_logs_folder, file_name
#         )
#         time.sleep(1)
#         logcat_capture_list.append((start_record_process, video_file_path))
#     sws_logger.debug("{}".format(logcat_capture_list))
#     return logcat_capture_list


# def stop_logcat_capture_on_all_devices(android_logcat_capture_list, test_case_status, retain_on_pass=False):
#     for logcat_process, logcat_file_name in android_logcat_capture_list:
#         Android_Screen_Recorder.stop_android_logcat_capture(logcat_process)
#         time.sleep(1)
#         if retain_on_pass:
#             return
#         else:
#             if os.path.exists(logcat_file_name) and test_case_status == "PASS":
#                 os.remove(logcat_file_name)


def set_pw_browser_log_folder(log_folder):
    my_builtin.set_suite_variable("${BROWSER_RECORDED_VIDEO_FILES_FOLDER}", str(log_folder).replace("\\", "/"))


def collect_ptt_pro_logs_on_all_devices(no_of_devices, test_case_logs_folder):
    no_of_devices = int(no_of_devices)
    pro_log_folder = "/sdcard/android/data/com.symbol.wfc.pttpro/files/"
    for i in range(1, no_of_devices + 1):
        dut_name = "DUT" + str(i)
        device_sn = my_builtin.get_variable_value("${" + dut_name + "}")
        device_sn = str(device_sn)
        folder_name = "PTT_Logs_{}_{}".format(dut_name, device_sn)
        command = "adb -s {} shell am broadcast -a com.symbol.wfc.pttpro.ACTION_COPY_DEBUGLOG".format(device_sn)
        _execute_adb_command_via_subprocess(command)
        time.sleep(1)
        command = "adb -s {} pull -a {} {}".format(
            device_sn, pro_log_folder, test_case_logs_folder + "\\" + folder_name
        )
        _execute_adb_command_via_subprocess(command)
        time.sleep(1)


def _execute_adb_command_via_subprocess(adb_command):
    sws_logger.debug("Executing Command : {}".format(adb_command))
    output = subprocess.getoutput(adb_command)
    sws_logger.debug("Output : {}".format(output.decode("utf-8")))


def validate_path(base_dir, path):
    # Ensure the path is within a specific directory
    full_path = os.path.abspath(os.path.join(base_dir, path))
    if not full_path.startswith(os.path.abspath(base_dir)):
        raise ValueError("Invalid path: Directory traversal attempt detected")
    return full_path
