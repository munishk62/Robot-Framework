from .SWSListenerWrapper import SWSListenerWrapper

__version__ = "1.0.1"


class SWSListener(SWSListenerWrapper):
    def __int__(self):
        SWSListenerWrapper.__init__(self)
