import platform
import subprocess
import sys
import time

os_name = platform.system()
command_filter_command = ""

if os_name == "Windows":
    print("Running on Windows")
    command_filter_command = "findstr"
elif os_name == "Linux":
    print("Running on Linux")
    command_filter_command = "grep"
elif os_name == "Darwin":
    print("Running on macOS")
    command_filter_command = "grep"
else:
    print("Unknown operating system")
    sys.exit(-1)


def _execute_adb_command(command):
    """
    Execute an ADB command and return its output.

    Args:
        command (str): The ADB command to execute. Must start with 'adb'.

    Returns:
        str: The output of the command if successful, error message otherwise.
    """
    print(f"Executing Command : {command}")
    if isinstance(command, str):
        if command.startswith("adb"):
            output = subprocess.getoutput(command)
            print("Output: ", output)
            return output
        else:
            print("Invalid adb command")
            return "Invalid adb command"
    else:
        print("Invalid data type. Command should be a string")
        return "Invalid data type. Command should be a string"


def press_power_button_on_android_device(device_sn):
    """
    Press the power button on an Android device using ADB.

    Args:
        device_sn (str): The serial number of the Android device.

    Returns:
        str: The output of the ADB command execution.
    """
    command = f"adb -s {device_sn} shell input keyevent 26"
    _execute_adb_command(command)


def check_device_status(device_sn):
    """
    Check if the Android device screen is locked.

    Args:
        device_sn (str): The serial number of the Android device.

    Returns:
        bool: True if screen is locked (OFF_LOCKED or ON_LOCKED), False otherwise.

    Raises:
        subprocess.CalledProcessError: If the ADB command fails.
    """
    screen_state = _execute_adb_command(
        f'adb -s {device_sn} shell dumpsys nfc | {command_filter_command} "mScreenState"'
    )
    output = screen_state.split("=")
    if output[1] == "OFF_LOCKED" or output[1] == "ON_LOCKED":
        return True
    else:
        return False


def press_power_button(device_sn):
    """
    Press the power button on an Android device.

    Args:
        device_sn (str): The serial number of the Android device.

    Returns:
        str: The output of the ADB command execution.
    """
    _execute_adb_command(f"adb -s {device_sn} shell input keyevent 26")


def get_sleep_time(device_sn):
    """
    Get the screen timeout setting of an Android device.

    Args:
        device_sn (str): The serial number of the Android device.

    Returns:
        str: The screen timeout value in milliseconds.
    """
    return _execute_adb_command(f"adb -s {device_sn} shell settings get system screen_off_timeout")


def count_recent_apps(device_sn):
    """
    Count the number of recent applications on an Android device.

    Args:
        device_sn (str): The serial number of the Android device.

    Returns:
        int: The number of recent applications.
    """
    command_to_execute = (
        f'adb -s {device_sn} shell dumpsys activity recents | {command_filter_command} "activityType=1"'
    )
    counter = _execute_adb_command(command_to_execute)
    counter = counter.count("activityType=1")
    return int(counter)


def check_app_installed(device_sn, package):
    """
    Check if a specific package is installed on an Android device.

    Args:
        device_sn (str): The serial number of the Android device.
        package (str): The package name to check.

    Returns:
        str: The package information if installed, empty string if not installed.
    """
    return _execute_adb_command(f"adb -s {device_sn} shell pm list packages | grep -w {package}")


def install_app_on_device_without_permission(device_sn, apk):
    """
    Install an APK on an Android device without granting permissions.

    Args:
        device_sn (str): The serial number of the Android device.
        apk (str): The path to the APK file.

    Returns:
        str: The output of the installation command.
    """
    return _execute_adb_command(f"adb -s {device_sn} install {apk}")


def install_app_on_device_with_permission(device_sn, app):
    """
    Install an APK on an Android device and grant all permissions.

    Args:
        device_sn (str): The serial number of the Android device.
        app (str): The path to the APK file.

    Returns:
        str: The output of the installation command.
    """
    return _execute_adb_command(f"adb -s {device_sn} install -g {apk}")


def force_stop_app(device_sn, package):
    """
    Force stop an application on an Android device.

    Args:
        device_sn (str): The serial number of the Android device.
        package (str): The package name to force stop.

    Returns:
        str: The output of the force stop command.
    """
    return _execute_adb_command(f"adb -s {device_sn} shell am force-stop {package}")


def click_with_position(device_sn, x, y):
    """
    Simulate a tap at specific coordinates on an Android device.

    Args:
        device_sn (str): The serial number of the Android device.
        x (int): The x-coordinate of the tap.
        y (int): The y-coordinate of the tap.

    Returns:
        str: The output of the tap command.
    """
    return _execute_adb_command(f"adb -s {device_sn} shell input tap {x} {y}")


def pull_logs_device(device_sn, target, destination):
    """
    Pull log files from an Android device to the local machine.

    Args:
        device_sn (str): The serial number of the Android device.
        target (str): The source path on the device.
        destination (str): The destination path on the local machine.

    Returns:
        str: The output of the pull command.
    """
    result = _execute_adb_command(f"adb -s {device_sn} pull -a {target} {destination}")
    time.sleep(3)
    return result


def get_device_info(device_sn, commd):
    """
    Execute a shell command on an Android device and get device information.

    Args:
        device_sn (str): The serial number of the Android device.
        commd (str): The shell command to execute.

    Returns:
        str: The output of the command, converted to lowercase with newlines removed.
    """
    result = _execute_adb_command(f"adb -s {device_sn} shell {commd}")
    return result.lower().replace("\n", "")


def push_file_to_device(device_sn, file, path):
    """
    Push a file from the local machine to an Android device.

    Args:
        device_sn (str): The serial number of the Android device.
        file (str): The source file path on the local machine.
        path (str): The destination path on the device.

    Returns:
        str: The output of the push command.
    """
    return _execute_adb_command(f"adb -s {device_sn} push {file} {path}")


def create_device_directory(device_sn, path):
    """
    Create a directory on an Android device.

    Args:
        device_sn (str): The serial number of the Android device.
        path (str): The path of the directory to create.

    Returns:
        str: The output of the mkdir command.
    """
    return _execute_adb_command(f"adb -s {device_sn} shell mkdir {path}")


def remove_device_directory(device_sn, path):
    """
    Remove a directory and its contents from an Android device.

    Args:
        device_sn (str): The serial number of the Android device.
        path (str): The path of the directory to remove.

    Returns:
        str: The output of the remove command.
    """
    return _execute_adb_command(f"adb -s {device_sn} shell rm -rR {path}")


def get_device_model(device_sn):
    """
    Get the model information of an Android device.

    Args:
        device_sn (str): The serial number of the Android device.

    Returns:
        str: The device model information.
    """
    return _execute_adb_command(f"adb -s {device_sn} shell getprop ro.product.device")


def execute_adb_command(device_sn, command):
    """
    Execute a custom ADB command on an Android device.

    Args:
        device_sn (str): The serial number of the Android device.
        command (str): The ADB command to execute.

    Returns:
        str: The output of the command.
    """
    return _execute_adb_command(f"adb -s {device_sn} {command}")


def execute_adb_shell_command(device_sn, command):
    """
    Execute a shell command on an Android device.

    Args:
        device_sn (str): The serial number of the Android device.
        command (str): The shell command to execute.

    Returns:
        str: The output of the shell command.
    """
    return _execute_adb_command(f"adb -s {device_sn} shell {command}")


def get_android_version(device_sn):
    """
    Get the Android version of a device.

    Args:
        device_sn (str): The serial number of the Android device.

    Returns:
        str: The Android version number.
    """
    return _execute_adb_command(f"adb -s {device_sn} shell getprop ro.build.version.release")


def check_and_uninstall_app(device_sn, app):
    """
    Check if an app is installed and uninstall it if present.

    Args:
        device_sn (str): The serial number of the Android device.
        app (str): The package name of the app to uninstall.

    Returns:
        str: The output of the uninstall command if the app was found and uninstalled,
             None if the app was not found.
    """
    output = _execute_adb_command(f"adb -s {device_sn} shell pm list packages {app}")
    if output:
        return _execute_adb_command(f"adb -s {device_sn} uninstall {app}")


# def get_pair(line):
#     key, sep, value = line.strip().partition(":")
#     return key.lower().replace(" ", ""), value.lower().replace(" ", "")


# def read2dict(filepath):
#     with open(filepath) as filedata:
#         details_dict = dict(get_pair(line) for line in filedata)
#     return details_dict


# def pull_log_file_count(device_sn, source, destination):
#     pull_logs_device(device_sn, source, destination)
#     count = len(
#         [
#             entry
#             for entry in os.listdir(destination)
#             if os.path.isfile(os.path.normpath(os.path.join(destination, entry)))
#         ]
#     )
#     print("overall file count", count)
#     shutil.rmtree(destination)
#     print("deleted temporary folder")
#     return count


# def read_all_log_lines(device_sn, source, destination):
#     pull_logs_device(device_sn, source, destination)
#     if os.path.isfile(destination):
#         with open(destination, "r") as f:
#             lines = f.readlines()
#         print("all lines in file is read")
#     else:
#         print("file not found", destination)
#         return
#     os.remove(destination)
#     print("deleted temp file")
#     return lines


# def get_log_size(device_sn, source, destination):
#     pull_logs_device(device_sn, source, destination)
#     if os.path.isfile(destination):
#         size = os.path.getsize(destination)
#         print(size)
#     else:
#         print("file not found", destination)
#         return
#     os.remove(destination)
#     print("deleted temp file")
#     return size


# def check_log_content_exists(device_sn, source, destination, check_string):
#     lines = read_all_log_lines(device_sn, source, destination)
#     flag = False
#     if len(lines) > 0:
#         if check_string in lines[-1]:
#             flag = True
#         else:
#             for line in lines:
#                 if check_string in line:
#                     flag = True
#     return flag


# def check_log_content_in_log_folder(device_sn, source, destination, check_string):
#     count = pull_log_file_count(device_sn, source, destination)
#     print("file count in ADB is", count)
#     while count > 0:
#         count -= 1
#         source_file = source + "/zwccomms_" + str(count) + ".log"
#         target_file = destination.replace("/logs", "") + "/zwccomms_" + str(count) + ".log"
#         print(source_file, target_file)
#         flag = check_log_content_exists(device_sn, source_file, target_file, check_string)
#         if flag and count != 0:
#             temp_count = count - 1
#             source_file = source + "/zwccomms_" + str(temp_count) + ".log"
#             target_file = destination.replace("/logs", "") + "/zwccomms_" + str(temp_count) + ".log"
#             print(source_file, target_file)
#             flag = check_log_content_exists(device_sn, source_file, target_file, check_string)
#             if flag:
#                 count = temp_count
#             break
#     return count


# def adb_check_file_exists(device_sn, source, destination, file_name):
#     pull_logs_device(device_sn, source, destination)
#     flag = os.path.isfile(os.path.normpath(os.path.join(destination, file_name)))
#     shutil.rmtree(destination)
#     return flag


# # # Testing
# if __name__ == "__main__":
#     device_sn = ""
#     # press_power_button_on_android_device(device_sn)

#     check_device_status(device_sn)
#     count_recent_apps(device_sn)
