import json
import platform
import shlex
import subprocess
import sys
import time

from ppadb.client import Client

os_name = platform.system()

if os_name == "Windows":
    print("Running on Windows")
elif os_name == "Linux":
    print("Running on Linux")
elif os_name == "Darwin":
    print("Running on macOS")
else:
    print("Unknown operating system")
    sys.exit(-1)


def start_appium_server(port, log):
    if not isinstance(port, int) or not (1024 <= port <= 65535):
        raise ValueError("Invalid port number. Port must be an integer between 1024 and 65535.")
    if not isinstance(log, str) or log not in ["info", "warn", "error", "debug"]:
        raise ValueError("Invalid log level. Log level must be one of 'info', 'warn', 'error', or 'debug'.")

    # appium_command = ["appium", "-p", str(port), "--relaxed-security", "--log-level", log]
    if os_name == "Windows":
        appium_cwd = None
    else:
        appium_cwd = "/usr/"
    command = f"appium -p {port} --relaxed-security --log-level {log}"
    if isinstance(command, str):
        # Safely split and quote the command string
        args = shlex.split(command)
    elif isinstance(command, (list, tuple)):
        # Ensure all arguments in the list are strings and quoted
        args = [shlex.quote(str(arg)) for arg in command]
    subprocess.Popen(args, cwd=appium_cwd, shell=True)
    time.sleep(3)


def stop_appium_server(appium_port):
    if os_name == "Windows":
        appium_port = int(appium_port)
        kill_command = f"npx kill-port {appium_port}"
        subprocess.getoutput(kill_command)
    else:
        cmd = f"kill $(lsof -t -i :{appium_port})"
        subprocess.getoutput(cmd)


def get_connected_android_device_list():
    device = []
    adb = Client(host="localhost", port=5037)
    devices = adb.devices()
    for dev in devices:
        device.append(dev.serial)
    return device


def convert_dictionary_to_json(a):
    b = json.dumps(a)
    return b


def get_machine_os_name():
    return platform.system()
