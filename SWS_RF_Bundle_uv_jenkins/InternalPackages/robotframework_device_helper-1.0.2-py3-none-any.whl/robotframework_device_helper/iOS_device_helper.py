import json
import subprocess


def get_version(udid):
    details = subprocess.getoutput(f"ios list --details")
    dict = json.loads(details)
    val = dict["deviceList"]
    for i in val:
        return i["ProductVersion"]


import subprocess


def reboot(udid):
    return subprocess.getoutput(f"ios reboot --udid={udid}")


def turn_on_assistive_mode(udid):
    return subprocess.getoutput(f"ios assistivetouch enable --udid={udid}")


def install_app_with_path(udid, app_path):
    return subprocess.getoutput(f"ios install --path={app_path} --udid={udid}")
