import datetime
import os

def dict_to_html_table(dictionary, title):
    """Convert a dictionary to an HTML table with styling."""
    html = f"<h2>{title}</h2>\n"
    html += "<table class='styled-table'>\n"
    html += "  <thead><tr><th>File</th><th>ID</th></tr></thead>\n"
    html += "  <tbody>\n"
    for key, value in dictionary.items():
        html += f"    <tr><td>{key}</td><td>{value}</td></tr>\n"
    html += "  </tbody>\n"
    html += "</table>\n"
    return html

def generate_html_report(combined_dict):
    """Generate an HTML report with combined dictionaries as tables with styling."""
    # # Get the current timestamp
    # timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Define the file name with timestamp
    file_name = f"robot_output_xml_analysis_report.html"
    
    # Define CSS styles for the report
    styles = """
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f4f4f9;
        }
        h2 {
            color: #333;
        }
        .styled-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 1.0em;
            min-width: 400px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }
        .styled-table th, .styled-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #dddddd;
        }
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }
        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }
        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
    </style>
    """

    html_content = f"<html>\n<head>\n<title>Combined Dictionary Report</title>\n{styles}\n</head>\n<body>\n"
    for title, dictionary in combined_dict.items():
        html_content += dict_to_html_table(dictionary, title)
        html_content += "<br>\n"  # Add a line break between tables
    html_content += "</body>\n</html>"

    # Write the HTML content to a file
    with open(file_name, "w") as file:
        file.write(html_content)

    # Print the absolute path of the file
    file_path = os.path.abspath(file_name)
    return file_path
    

# # Example usage
# combined_dict = {
#     'Personal Information': {
#         'Name': 'Alice',
#         'Age': 28,
#         'City': 'New York'
#     },
#     'Professional Information': {
#         'Company': 'OpenAI',
#         'Role': 'Engineer',
#         'Experience': '5 years'
#     }
# }

# generate_html_report(combined_dict)
