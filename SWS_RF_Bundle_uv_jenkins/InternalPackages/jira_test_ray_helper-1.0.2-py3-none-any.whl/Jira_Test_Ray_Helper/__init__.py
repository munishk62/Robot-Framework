import argparse
import json
import os
import sys
import threading
import time

from Jira_Test_Ray_Helper import Jira_Test_Ray
from Jira_Test_Ray_Helper import robot_file_helper
from Jira_Test_Ray_Helper.Jira_Test_Ray_Logger import sws_logger as my_logger

__version__ = "1.0.2"
__author__ = "Balaji.D"

default_chunk_count = 10

wfc_component_list = [
    "zwc",
    "sync_service",
    "exm",
    "pvm",
    "ptt_pro",
    "ptt_express",
    "zebra_voice",
    "pfm",
    "zems_server",
    "zems_web_client",
    "iwg",
    "localization",
    "channel_portal",
    "task_tracker",
    "las",
    "idp",
    "pro_manager_service",
]


def validate_path(base_dir, path):
    # Normalize the path
    print("base_dir : ", base_dir)
    print("path : ", path)
    normalized_path = os.path.normpath(path)
    print("normalized_path : ", normalized_path)
    # Ensure the path is within the base directory
    full_path = os.path.abspath(os.path.join(base_dir, normalized_path))
    print("full_path : ", full_path)
    if not full_path.startswith(os.path.abspath(base_dir)):
        raise ValueError("Invalid path: Directory traversal attempt detected")
    return full_path


def get_chunks(input_list, chunk_length):
    """
    Splits the input_list into chunks of size chunk_length.

    Args:
        input_list (list): The list to be split into chunks.
        chunk_length (int): The size of each chunk.

    Yields:
        list: A chunk of size chunk_length from the input_list.
    """
    for i in range(0, len(input_list), chunk_length):
        yield input_list[i : i + chunk_length]


def split_result_into_chunks(test_case_result_dict):
    """
    Splits the given test case result dictionary into chunks based on a default chunk count.

    Args:
        test_case_result_dict (dict): A dictionary containing test case results.

    Returns:
        list: A list of chunks, where each chunk is a list of test case IDs.
    """
    test_case_id_list_full = list(test_case_result_dict.keys())
    test_case_id_list_chunks = list(
        get_chunks(test_case_id_list_full, default_chunk_count)
    )
    return test_case_id_list_chunks


def update_each_result_chunk_in_thread(
    test_case_id_list_chunks,
    test_ray_test_plan_id,
    test_ray_test_cycle_name,
    test_case_result_dict,
    skip_fail,
):
    """
    Update each result chunk in a separate thread.

    Args:
        test_case_id_list_chunks (list): A list of chunks containing test case IDs.
        test_ray_test_plan_id (str): The ID of the Test_Ray test plan.
        test_ray_test_cycle_name (str): The name of the Test_Ray test cycle.
        test_case_result_dict (dict): A dictionary containing test case IDs as keys and their corresponding result
                                      dictionaries as values.

    Returns:
        None
    """
    my_logger.info("Updating Test Result in Jira Test_Ray")
    for test_case_id_list_chunk in test_case_id_list_chunks:
        result_update_threads = []
        for test_case_id in test_case_id_list_chunk:
            current_test_case_result_dict = test_case_result_dict[test_case_id]
            result_update_thread = threading.Thread(
                target=Jira_Test_Ray.update_test_result_to_jira_test_ray_test_cycle,
                args=(
                    test_ray_test_plan_id,
                    test_ray_test_cycle_name,
                    test_case_id,
                    current_test_case_result_dict,
                    skip_fail,
                ),
            )
            result_update_thread.name = test_case_id
            result_update_threads.append(result_update_thread)
            result_update_thread.start()
        time.sleep(5)
        for current_thread in result_update_threads:
            current_thread.join()


def construct_id_mapping_list(json_file_path):
    """
    Constructs a list of ID mappings from a JSON file.

    Args:
        json_file_path (str): The path to the JSON file.

    Returns:
        list: A list of dictionaries containing the old and new IDs.
    """
    my_logger.info("Constructing ID Mapping List")
    id_mapping_list = []

base_directory = os.getcwd()  # Define a safe base directory
base = os.path.abspath(base_directory)
# Handle or reject the input
try:
    validated_path = validate_path(base, json_file_path)
    my_path = os.path.abspath(os.path.join(base, validated_path))
    if my_path.startswith(base):
        with open(my_path) as json_file:
            data = json.load(json_file)
            for key in data:
                if "polarion_id" in data[key]:
                    id_mapping_list.append(
                        {
                            "old_id": data[key]["polarion_id"],
                            "new_id": data[key]["jira_test_ray_id"],
                        }
                    )
        my_logger.debug(id_mapping_list)
        return id_mapping_list
    except ValueError as e:
        my_logger.error("Invalid json file path: {}".format(json_file_path))
        sys.exit(-1)


def sync_test_case_id(args):
    """
    Synchronizes the test case IDs for a given component.

    Args:
        args (object): The arguments object containing the component name.

    Returns:
        None
    """
    component_name = str(args.component_name).lower().strip()
    assert (
        component_name in wfc_component_list
    ), "Component name is incorrect or support need to be added : {}".format(
        component_name
    )
    json_file_path = Jira_Test_Ray.get_test_cases_from_jira_test_ray_for_component(
        component_name
    )
    id_mapping_list = construct_id_mapping_list(json_file_path)
    my_logger.info(
        "Updating test case id in robot files for : {}".format(component_name)
    )
    robot_file_helper.update_test_case_id_for_component(component_name, id_mapping_list)
    # if os.path.exists(json_file_path):
    #     my_logger.debug("Removing json file : {}".format(json_file_path))
    #     os.remove(json_file_path)


def update_test_result(args):
    """
    Updates the test result in Jira for a given test plan and test cycle using the .xml file generated during
    the automation run.

    Args:
        args (object): An object containing the following attributes:
            - output_file (str): The path to the robot output XML file.
            - test_plan_id (str): The ID of the test plan.
            - test_cycle_name (str): The name of the test cycle.

    Returns:
        None
    """
    extension = args.output_file.split(".")[-1].lower()
    my_logger.info("Output XML File : {}".format(args.output_file))
    my_logger.info("Test Plan ID : {}".format(args.test_plan_id))
    my_logger.info("Test Cycle Name : {}".format(args.test_cycle_name))
    my_logger.info("Skip Fail : {}".format(args.skip_fail))
    if not os.path.exists(args.output_file):
        my_logger.error(
            "robot output xml file path is incorrect : {}".format(args.output_file)
        )
        sys.exit(-1)
    my_logger.info("Parsing robot Output file")
    test_case_result_dict = {}
    if extension == "xml":
        test_case_result_dict = robot_file_helper.check_tests(args.output_file)
    elif extension == "json":
        with open(args.output_file, "r") as file:
            test_case_result_dict = json.load(file)
    test_case_id_list_chunks = split_result_into_chunks(test_case_result_dict)
    update_each_result_chunk_in_thread(
        test_case_id_list_chunks,
        args.test_plan_id,
        args.test_cycle_name,
        test_case_result_dict,
        args.skip_fail,
    )
    my_logger.info("Result Update Completed")


def get_test_cases_from_cycle(args):
    """
    Gets the test cases from a given test cycle.

    Args:
        args (object): An object containing the following attributes:
            - test_plan_id (str): The ID of the test plan.
            - test_cycle_name (str): The name of the test cycle.

    Returns:
        None
    """
    my_logger.info("Test Plan ID : {}".format(args.test_plan_id))
    my_logger.info("Test Cycle Name : {}".format(args.test_cycle_name))
    Jira_Test_Ray.get_test_cases_from_test_cycle_for_execution(
        args.test_plan_id, args.test_cycle_name
    )


def convert_xml_to_json(args):
    """
    Convert an XML file to JSON format and save the output to the specified path.

    Args:
        args (argparse.Namespace): The command-line arguments.
    """
    try:
        dic = robot_file_helper.check_tests(rf"{args.xml_path}")
        json_path, json_string = robot_file_helper.dict_to_json(
            dic, rf"{args.json_path}"
        )
        my_logger.info(f"JSON file created at {json_path}")
    except Exception as e:
        print(f"An error occurred: {e}")


def cli():
    """
    Command line interface for Jira_Test_Ray_Helper.

    Usage:
        jira_test_ray_helper sync_test_case_id -c <component_name>
        jira_test_ray_helper update_test_result -o <output_file> -tp <test_plan_id> -tc <test_cycle_name>
        jira_test_ray_helper update_test_result -o <output_file> -tp <test_plan_id> -tc <test_cycle_name> -sf
        jira_test_ray_helper get_test_cases_from_cycle -tp <test_plan_id> -tc <test_cycle_name>
        jira_test_ray_helper convert_xml_to_json --xml <path_to_xml_file> --json <path_to_the_output_json_file>

    """
    global_parser = argparse.ArgumentParser()
    global_parser.add_argument("-v", "--version", action="version", version=__version__)
    subparsers = global_parser.add_subparsers(title="commands")

    id_sync_parser = subparsers.add_parser(
        "sync_test_case_id", help="update test case id for given component"
    )
    id_sync_parser.add_argument(
        "-c",
        "--component_name",
        action="store",
        help="Ex: {}".format(str(wfc_component_list)),
    )
    id_sync_parser.set_defaults(func=sync_test_case_id)

    result_update_parser = subparsers.add_parser(
        "update_test_result",
        help="update test result for given test run using the .xml",
    )
    result_update_parser.add_argument(
        "-o",
        "--output_file",
        action="store",
        help="provide robot output xml file path",
    )
    result_update_parser.add_argument(
        "-tp", "--test_plan_id", action="store", help="provide Test_Ray test plan id"
    )
    result_update_parser.add_argument(
        "-tc",
        "--test_cycle_name",
        action="store",
        help="provide Test_Ray test cycle name",
    )
    result_update_parser.add_argument(
        "-sf",
        "--skip_fail",
        action="store_true",
        default=False,
        help="skip updating result for failed test cases",
    )
    result_update_parser.set_defaults(func=update_test_result)

    get_test_cases_parser = subparsers.add_parser(
        "get_test_cases_from_cycle", help="get test cases from given test cycle"
    )
    get_test_cases_parser.add_argument(
        "-tp", "--test_plan_id", action="store", help="provide Test_Ray test plan id"
    )
    get_test_cases_parser.add_argument(
        "-tc",
        "--test_cycle_name",
        action="store",
        help="provide Test_Ray test cycle name",
    )
    get_test_cases_parser.set_defaults(func=get_test_cases_from_cycle)

    convert_xml_parser = subparsers.add_parser(
        "convert_xml_to_json", help="convert robot output xml file to JSON format with test case results details"
    )
    convert_xml_parser.add_argument(
        "--xml",
        dest="xml_path",
        action="store",
        help="path to the XML file",
        required=True,
    )
    convert_xml_parser.add_argument(
        "--json",
        dest="json_path",
        action="store",
        default=os.path.join(os.getcwd(), "jira_test_ray_result.json"),
        help="path to the output JSON file",
    )
    convert_xml_parser.set_defaults(func=convert_xml_to_json)

    args = global_parser.parse_args()
    args.func(args)
