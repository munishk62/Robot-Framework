import json
import os
import re

from Jira_Test_Ray_Helper.Jira_Test_Ray_Logger import sws_logger as my_logger
from robot.api import ExecutionResult, ResultVisitor
from robot.api.parsing import ModelVisitor, Token, get_model

from .report_generator import generate_html_report

test_case_result_dict = {}

VOIP_TS_ROOT = r"C:\RFS_CI\GIT_REPO\WFC_Validation_RFS\RFS\TS\ANDROID\VOIP"

TS_ROOT_FOLDER_DICT = {
    "ZWC_FOLDER_PATH": r"{}\ZWC".format(VOIP_TS_ROOT),
    "SYNC_SERVICE_FOLDER_PATH": r"{}\FLW_Sync_Service".format(VOIP_TS_ROOT),
    "EXM_FOLDER_PATH": r"{}\ExtensionManager".format(VOIP_TS_ROOT),
    "PVM_FOLDER_PATH": r"{}\Provisioning_Manager".format(VOIP_TS_ROOT),
    "PTT_PRO_FOLDER_PATH": r"{}\PTTPro".format(VOIP_TS_ROOT),
    "PTT_EXPRESS_FOLDER_PATH": r"{}\PTTExpress".format(VOIP_TS_ROOT),
    "ZEBRA_VOICE_FOLDER_PATH": r"{}\WFCVoice".format(VOIP_TS_ROOT),
    "PFM_FOLDER_PATH_CLIENT": r"{}\DFS".format(VOIP_TS_ROOT),
    "PFM_FOLDER_PATH": r"{}\Profile_Manager\PFM_API".format(VOIP_TS_ROOT),
    "ZEMS_SERVER_FOLDER_PATH": r"{}\ZEMS".format(VOIP_TS_ROOT),
    "ZEMS_WEB_CLIENT_FOLDER_PATH": r"{}\ZEMS_Web_Client".format(VOIP_TS_ROOT),
    "IWG_FOLDER_PATH": r"{}\IWG".format(VOIP_TS_ROOT),
    "LOCALIZATION_FOLDER_PATH": r"{}\WFCVoiceLocalization".format(VOIP_TS_ROOT),
    "CHANNEL_PORTAL_FOLDER_PATH": r"{}\ChannelPartner".format(VOIP_TS_ROOT),
    "TASK_TRACKER_FOLDER_PATH": r"{}\TaskTracker".format(VOIP_TS_ROOT),
    "LAS_FOLDER_PATH": r"{}\WFC_LAS".format(VOIP_TS_ROOT),
    "IDP_FOLDER_PATH": r"{}\ZEMS_Web_Client".format(VOIP_TS_ROOT),
    "PRO_MANAGER_SERVICE_FOLDER_PATH": r"{}\PTT_PRO_Manager_Service".format(VOIP_TS_ROOT),
}


class UpdateTestId(ModelVisitor):
    """
    A visitor class to update test case IDs in a Robot Framework model.

    Attributes:
        old_id (str): The old test case ID to be replaced.
        new_id (str): The new test case ID to replace the old ID with.
    """

    def __init__(self, old_id, new_id):
        self.old_id = old_id
        self.new_id = new_id

    def get_test_case_id(self, name):
        """
        Extracts the test case ID from the given test case name.

        Args:
            name (str): The test case name.

        Returns:
            str: The test case ID.
        """
        return name.split(" ")[0].strip()

    def visit_TestCaseName(self, node):
        """
        Visits a TestCaseName node and updates the test case ID if it matches the old ID.

        Args:
            node (TestCaseName): The TestCaseName node to visit.
        """
        if self.get_test_case_id(node.name) == self.old_id:
            token = node.get_token(Token.TESTCASE_NAME)
            token.value = node.name.replace(self.old_id, self.new_id)


def _update_test_case_id_for_component(component_suite_root_folder, id_mapping_list):
    """
    Updates the Test Case ID for a component suite.

    Args:
        component_suite_root_folder (str): The root folder of the component suite.
        id_mapping_list (list): A list of dictionaries containing the old and new Test Case IDs.

    Returns:
        None
    """
    my_logger.info("Updating Test Case ID : {}".format(component_suite_root_folder))
    folder_path = component_suite_root_folder
    assert os.path.exists(folder_path), "{} Not Present in the repository".format(folder_path)
    for root, dirs, files in os.walk(folder_path):
        for file_name in files:
            if file_name.endswith(".robot") and "__Dir" not in file_name:
                robot_test_suite_file_path = os.path.normpath(os.path.join(root, file_name))
                my_logger.info("Updating Test Case ID : {}".format(robot_test_suite_file_path))
                model = get_model(robot_test_suite_file_path)
                for element in id_mapping_list:
                    renamer = UpdateTestId(element["old_id"], element["new_id"])
                    renamer.visit(model)
                model.save()


def update_test_case_id_for_component(component_name, id_mapping_list):
    """
    Updates the Test Case ID for a component.

    Args:
        component_name (str): The name of the component.
        id_mapping_list (list): A list of dictionaries containing the old and new Test Case IDs.

    Returns:
        None
    """
    component_folder_name_key = "{}_FOLDER_PATH".format(component_name.upper())
    component_folder_name = TS_ROOT_FOLDER_DICT[component_folder_name_key]
    _update_test_case_id_for_component(component_folder_name, id_mapping_list)


count_duplicate = 0
count_invalid = 0
count = 0
dup = set()
invalid_format_dict = {}
duplicate_dict = {}


class ExecutionTimeChecker(ResultVisitor):
    """
    A class that checks the execution time of test cases.

    Methods:
        __init__(): Initializes the ExecutionTimeChecker object.
        visit_test(test): Visits a test case and stores its result in a dictionary.
    """

    def __init__(self):
        pass

    def visit_test(self, test):
        global count
        global count_duplicate
        global count_invalid
        pattern = r"^[A-Za-z]+-\d+$"
        count += 1
        test_case_name = str(test.name.strip()).split(" ")[0]
        suite_path = str(test.source)
        current_test_case_result_dict = {
            "verdict": test.status,
            "comments": str(test.message),
            "version_info": "",
        }
        if not re.match(pattern, test_case_name):
            my_logger.warning(f"Warning: {test_case_name} not matching the required format")
            if suite_path in invalid_format_dict:
                invalid_format_dict[suite_path].append(test_case_name)
            else:
                invalid_format_dict[suite_path] = [test_case_name]
            count_invalid += 1
            return
        if test_case_name in test_case_result_dict:
            my_logger.warning(f"Warning: {test_case_name} duplicated")
            dup.add(test_case_name)
            if suite_path in duplicate_dict:
                duplicate_dict[suite_path].append(test_case_name)
            else:
                duplicate_dict[suite_path] = [test_case_name]
            count_duplicate += 1
            return
        test_case_result_dict[test_case_name] = current_test_case_result_dict


def check_tests(xml_file_path):
    """
    Check the tests in the specified XML file.

    Args:
        xml_file_path (str): The path to the XML file.

    Returns:
        dict: A dictionary containing the test case results.
    """
    global count_duplicate
    try:
        result = ExecutionResult(xml_file_path)
        result.visit(ExecutionTimeChecker())
    except TypeError:
        my_logger.exception(__doc__)
    finally:
        for i in dup:
            test_case_result_dict.pop(i)
            count_duplicate += 1
        my_logger.info(
            f"""\nTotal Test Cases: {count}
          Valid Test Cases: {count - count_invalid - count_duplicate}
          Invalid Test Title Format: {count_invalid}
          Duplicate Test Cases: {count_duplicate}"""
        )
        # print(f"Invalid Test Title Format in {len(invalid_format_dict)} files")
        report_dictionary = {
            "Invalid Test Title Format": invalid_format_dict,
            "Duplicate Test Cases": duplicate_dict,
        }
        # for key, value in invalid_format_dict.items():
        #     print(f"{key}: {value}")
        # print(f"Duplicate Test Cases in {len(duplicate_dict)} files")
        # for key, value in duplicate_dict.items():
        #     print(f"{key}: {value}")
        report_file = generate_html_report(report_dictionary)
        my_logger.info(f"Report file generated: {report_file}")


# def validate_path(base,file):
#     my_path = os.path.abspath(os.path.join(base, file))
#     if not my_path.startswith(base):
#         print(f"File '{my_path}' is not within the allowed directory.")
#         raise ValueError("File path is outside of allowed directory")
#     return my_path


def dict_to_json(dictionary, json_path):
    json_string = json.dumps(dictionary, indent=4)
    BASE_DIRECTORY = os.getcwd()
    my_path = os.path.abspath(os.path.join(BASE_DIRECTORY, json_path))
    if not my_path.startswith(BASE_DIRECTORY):
        print(f"File '{my_path}' is not within the allowed directory.")
        raise ValueError("File path is outside of allowed directory")
    with open(my_path, "w") as f:
        f.write(json_string)
    return my_path, json_string


# def dict_to_json(dictionary, json_path):
#     json_string = json.dumps(dictionary, indent=4)
#     BASE_DIRECTORY = "/path/to/safe/directory"
#     my_path = validate_path(BASE_DIRECTORY, json_path)
#     with open(my_path, "w") as f:
#         f.write(json_string)
#     return my_path, json_string


# if __name__ == "__main__":
#     # dic = check_tests(sys.argv[2])
#     dic = check_tests(
#         r"C:\Users\vk7435\Downloads\Jira_Test_Ray_Project\xunit\output.xml"
#     )
#     # for key in dic:
#     #     if "WFCNG" not in key:
#     #         print(key)
#     # print(count)
#     # print(len(lst), len(st))

#     print("file output.json created in current directory")
