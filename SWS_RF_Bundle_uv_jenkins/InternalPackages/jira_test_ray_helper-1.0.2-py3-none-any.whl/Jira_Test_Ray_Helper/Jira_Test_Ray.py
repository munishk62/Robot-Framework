import json
import os
import sys

import requests
from dotenv import load_dotenv

from Jira_Test_Ray_Helper.Jira_Test_Ray_Logger import sws_logger as my_logger

load_dotenv()

IS_JIRA_ENV_VAR_SET = True
JIRA_URL = os.getenv("JIRA_URL")
JIRA_AUTH_TOKEN = "{} {}".format(os.getenv("JIRA_AUTH_TYPE"), os.getenv("JIRA_TOKEN"))

if JIRA_URL is None or JIRA_AUTH_TOKEN is None:
    IS_JIRA_ENV_VAR_SET = False

test_ray_result_verdict_dict = {
    "pass": "Passed",
    "fail": "Failed",
    "blocked": "Blocked",
}


def _check_jira_env_var():
    if not IS_JIRA_ENV_VAR_SET:
        my_logger.error("JIRA ENV Variables are not set")
        sys.exit(-1)


def update_test_result_to_jira_test_ray_test_cycle(
    test_plan_id,
    test_cycle_name,
    test_case_id,
    current_test_case_result_dict,
    skip_fail,
):
    """
    Updates the test result of a test case in Jira Test_Ray test cycle.

    Args:
        test_plan_id (str): The ID of the test plan.
        test_cycle_name (str): The name of the test cycle.
        test_case_id (str): The ID of the test case.
        current_test_case_result_dict (dict): A dictionary containing the current test case result.

    Returns:
        None
    """
    _check_jira_env_var()
    test_ray_result_update_end_point = (
        "/rest/synapse/latest/public/testPlan/{}/cycle/{}/updateTestRun".format(
            test_plan_id, test_cycle_name
        )
    )
    url = JIRA_URL + test_ray_result_update_end_point
    test_verdict = str(current_test_case_result_dict["verdict"]).strip().lower()
    if skip_fail and test_verdict == "fail":
        my_logger.info("Skipping Result Update for Failed Test case")
    else:
        test_comment = str(current_test_case_result_dict["comments"]).strip()
        version_info = str(current_test_case_result_dict["version_info"]).strip()
        if version_info == "None":
            version_info = ""
        payload = json.dumps(
            {
                "testcaseKey": "{}".format(test_case_id),
                "result": "{}".format(test_ray_result_verdict_dict[test_verdict]),
                "comment": "{}\n{}".format(test_comment, version_info),
            }
        )
        headers = {"Content-Type": "application/json", "Authorization": JIRA_AUTH_TOKEN}
        response = requests.request("POST", url, headers=headers, data=payload)
        response_code = response.status_code
        if response_code == 200:
            my_logger.info("Result Updated Successfully")
        elif response_code == 401:
            my_logger.error("{} : Authentication Issue".format(response_code))
            sys.exit(-1)
        elif response_code == 403:
            my_logger.exception("{} : Forbidden error".format(response_code))
            sys.exit(-1)
        else:
            my_logger.error("Error in result Update: {} ".format(response.text))


def _get_test_case_info_from_jira_test_ray_test_suite_in_json(
    test_ray_test_plan_id, json_file_name
):
    """
    Retrieves test case information from Jira Test_Ray Test Suite and saves it in a JSON file.

    Args:
        test_ray_test_plan_id (str): The ID of the Jira Test_Ray Test Suite.
        json_file_name (str): The name of the JSON file to save the test case information.

    Returns:
        str: The file path of the saved JSON file.
    """
    my_logger.debug("Getting Test cases from Jira Test_Ray Test Suite")
    url = "{}/rest/synapse/latest/public/testSuite/testSuite/{}".format(
        JIRA_URL, test_ray_test_plan_id
    )
    headers = {"Authorization": JIRA_AUTH_TOKEN}
    response = requests.request("GET", url, headers=headers)
    assert (
        response.status_code == 200
    ), "Error in getting test cases from Jira Test_Ray : {}".format(
        response.status_code
    )
    total_test_cases = len(response.json()["testCases"])
    my_logger.info("Total Test cases Found : {}".format(total_test_cases))
    jira_test_case_dict = {}
    count = 0
    for test_case in response.json()["testCases"]:
        test_case_id = test_case["key"]
        test_case_title = test_case["summary"].encode("utf-8").decode("utf-8")
        jira_test_case_dict[test_case_id] = {
            "summary": test_case_title,
            "jira_test_ray_id": test_case_id,
        }
        my_logger.debug(test_case_id + " " + test_case_title)
        url = "{}/rest/synapse/latest/public/testCase/{}/steps".format(
            JIRA_URL, test_case_id
        )
        response = requests.request("GET", url, headers=headers)
        assert response.status_code == 200
        if len(response.json()) == 1:
            count += 1
            jira_test_case_dict[test_case_id]["polarion_id"] = response.json()[0][
                "stepData"
            ]
            my_logger.info(
                "Test cases read : {} out of {}".format(count, total_test_cases)
            )
    my_logger.debug(jira_test_case_dict)
    # Sanitize the filename to prevent path injection
    safe_file_name = "".join(
        c for c in json_file_name if c.isalnum() or c in "._-"
    )
    # Ensure the file is created in a safe directory
    output_dir = os.getcwd()  # Or any other safe directory
    json_file_location = os.path.normpath(os.path.join(output_dir, safe_file_name))
    with open(json_file_location, "w") as outfile:
        json.dump(jira_test_case_dict, outfile, indent=4)
    my_logger.info("json file dumped successfully : {}".format(json_file_location))
    my_logger.info("Total Test cases Found : {}".format(len(jira_test_case_dict)))
    return json_file_location


def get_test_cases_from_jira_test_ray_for_component(component_name):
    """
    Retrieves test cases from Jira Test_Ray for a given component.

    Args:
        component_name (str): The name of the component.

    Returns:
        str: The file path of the saved JSON file.
    """
    my_logger.info(
        "Getting Test cases from Jira Test_Ray for component : {}".format(
            component_name
        )
    )
    json_file_name = "{}_test_cases.json".format(component_name.lower())
    test_suite_id = os.getenv("JIRA_{}_SUITE_ID".format(component_name.upper()))
    return _get_test_case_info_from_jira_test_ray_test_suite_in_json(
        test_suite_id, json_file_name
    )


def get_test_cases_from_test_cycle_for_execution(test_plan_id, test_cycle_name):
    """
    Retrieves test cases from a test cycle in Jira Test_Ray.

    Args:
        test_plan_id (str): The ID of the test plan.
        test_cycle_name (str): The name of the test cycle.

    Returns:
        dict: Test case information from Jira Test_Ray test cycle in JSON format.
    """
    my_logger.info("Getting Test cases from Jira Test_Ray Test Cycle")
    test_cases_to_execute_list = []
    url = "{}/rest/synapse/latest/public/testPlan/{}/cycle/{}/testRuns".format(
        JIRA_URL, test_plan_id, test_cycle_name
    )
    headers = {"Authorization": JIRA_AUTH_TOKEN}
    response = requests.request("GET", url, headers=headers)
    if response.status_code != 200:
        print("Error in getting test cases from Jira Test_Ray")
        print("Response Status Code : {}".format(response.status_code))
        print("Response Text : {}".format(response.text))
        print("Response Reason : {}".format(response.reason))
        sys.exit(-1)
    print("Total Test cases Found : {}".format(len(response.json())))
    for test_case in response.json():
        if test_case["status"] == "Not Tested" or test_case["status"] == "Failed":
            test_cases_to_execute_list.append(test_case["testCaseKey"])
    print("Total Test cases to Execute : {}".format(len(test_cases_to_execute_list)))
    # code to write each test cases id from the list to a file with timestamp in the file name
    current_folder = os.getcwd()
    file_name = "{}_test_cases_to_execute.txt".format(test_plan_id)
    file_path = os.path.normpath(os.path.join(current_folder, file_name))
    with open(file_path, "w") as f:
        for item in test_cases_to_execute_list:
            f.write("-t {}*\n".format(item))
        f.write("-v TEST_RAY_TEST_PLAN_ID:{}\n".format(test_plan_id))
        f.write("-v TEST_RAY_TEST_CYCLE_NAME:{}\n".format(test_cycle_name))
        print("Test cases to Execute file dumped successfully : {}".format(file_path))
    return file_path


# Testing
# if __name__ == "__main__":
#     # json_file = get_sync_service_test_cases_from_jira_test_ray()
#     # json_file = get_zwc_test_cases_from_jira_test_ray()
#     # my_logger = logging.getLogger("WFCLogger")
#     #get_test_cases_from_test_cycle_for_execution("WFC-23253","ZWC_Automation_Result_Test_cycle")
#     get_test_cases_from_test_cycle_for_execution("WFM-28144","Major_Release_Validation")
