import logging
import os
import time
from colorlog import ColoredFormatter
from datetime import datetime
from colorama import Fore, Style

console_log_format = "%(asctime)s.%(msecs)03d %(message)s "

# Get the operating system type
os_type = os.name

# Set the log file path based on the operating system type
if os_type == "nt":  # Windows
    test_ray_log_folder = r"C:\Temp\Test_Ray_Logs"
elif os_type == "posix":  # Linux
    test_ray_log_folder = os.path.normpath(os.path.join(os.getcwd(), "Test_Ray_Logs"))
else:  # mac
    test_ray_log_folder = "/tmp/Test_Ray_Logs"

today_date = datetime.now()
formatted_date = today_date.strftime("%Y_%m_%d")

test_ray_log_folder = os.path.normpath(
    os.path.join(test_ray_log_folder, formatted_date)
)

if not os.path.exists(test_ray_log_folder):
    os.makedirs(test_ray_log_folder)
    time.sleep(1)

date_format = "%Y-%m-%d %H:%M:%S"
color_log_format = "%(log_color)s" + console_log_format
primary_log_colors = {
    "DEBUG": "cyan",
    "INFO": "green",
    "WARNING": "bold_yellow",
    "ERROR": "bold_red",
    "CRITICAL": "bold_purple",
}

stream_handler_format = ColoredFormatter(
    color_log_format,
    date_format,
    log_colors=primary_log_colors,
    secondary_log_colors={
        "message": {"INFO": "red", "ERROR": "red", "CRITICAL": "red"}
    },
    style="%",
)

sws_logger = logging.getLogger(__name__)
sws_logger.propagate = False
sws_logger.setLevel(logging.DEBUG)

stream_handler = logging.StreamHandler()
stream_handler.setLevel(logging.INFO)
stream_handler.setFormatter(stream_handler_format)
sws_logger.addHandler(stream_handler)

file_log_format = (
    "%(asctime)s.%(msecs)03d [%(levelname)-8s] [%(filename)s:%(lineno)d] %(message)s "
)
log_file_name = "WL_{}.log".format(datetime.now().strftime("%Y_%m_%d_%H_%M_%S_%f")[:-4])
log_file_location = os.path.normpath(os.path.join(test_ray_log_folder, log_file_name))
file_handler = logging.FileHandler(log_file_location)
file_handler.setLevel(logging.DEBUG)
file_handler_format = logging.Formatter(file_log_format, date_format)
file_handler.setFormatter(file_handler_format)
sws_logger.addHandler(file_handler)

sws_logger.info("log file location : {}".format(log_file_location))


def color_print(message, message_color=Fore.CYAN):
    message = str(message)
    print(message_color + message)
    print(Style.RESET_ALL)
