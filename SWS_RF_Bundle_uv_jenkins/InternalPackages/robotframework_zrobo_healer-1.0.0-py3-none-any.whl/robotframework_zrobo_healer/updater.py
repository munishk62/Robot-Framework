import os

from .healer_logger import robot_healer_logger


def check_and_update_robot_variable_value(old_value, new_value, file_path):
    """
    Check and update the value of a Robot Framework variable in a given file.

    This function searches for a specific variable value in the specified file,
    and if found, replaces it with a new value. The function returns a tuple
    indicating whether the variable was found and updated, and the line numbers
    where the updates occurred.

    Args:
        old_value (str): The old value of the variable to be replaced.
        new_value (str): The new value to replace the old value with.
        file_path (str): The path to the file where the variable value should be updated.

    Returns:
        tuple: A tuple containing a boolean indicating if the variable was found and updated,
               and a list of integers representing the line numbers where the updates occurred.
               If the variable was not found, the list will be empty.
    """
    lines = []
    variable_found = False
    line_numbers = []
    BASE_DIRECTORY = os.getcwd()
    my_path = os.path.abspath(os.path.join(BASE_DIRECTORY, file_path))
    if my_path.startswith(BASE_DIRECTORY):
        robot_healer_logger.debug(f"Reading File: {my_path}")
        with open(my_path, "r", encoding="utf-8") as file:
            lines = file.readlines()

        # if file_path.endswith('.py'):
        #     if old_value.__contains__("'"):
        #         pass
        #     else:
        #         new_value = new_value.replace("'", '"')

        for i, line in enumerate(lines):
            if old_value in line:
                new_line = line.replace(old_value, new_value)
                if new_line != line:
                    lines[i] = new_line
                    variable_found = True
                    line_numbers.append(i + 1)

        if variable_found:
            BASE_DIRECTORY = os.getcwd()
            my_path = os.path.abspath(os.path.join(BASE_DIRECTORY, file_path))
            if not my_path.startswith(BASE_DIRECTORY):
                print(f"File '{my_path}' is not within the allowed directory.")
                raise ValueError("File path is outside of allowed directory")
            with open(my_path, "w") as file:
                file.writelines(lines)

            # print(f"Replaced '{old_value}' with '{new_value}' in {file_path}")
        # else:
        #     print(f"Variable '{old_value}' not found in file '{file_path}'")

        return variable_found, line_numbers
    else:
        return False, -1


# if __name__ == "__main__":
#     # # Example usage
#     # file_path = r"C:\RFS_CI\GIT_REPO\RF_Auto_Healer\Resource\Web_Sample.resource"
#     # old = "id=paswwwwwww"
#     # new = "//*[@id='user-name']"
#     # check_and_update_robot_variable_value(old, new, file_path)

#     # file_path = r"C:\RFS_CI\GIT_REPO\RF_Auto_Healer\Resource\Web_Sample.resource"
#     # old = "//*[@id='user-namaaaa']"aaq
#     # new = "//*[@id='user-name']"
#     # check_and_update_robot_variable_value(old, new, file_path)

#     file_path = r"C:\RFS_CI\GIT_REPO\rflx-wfm-sanity\Resources\Web\Common\Locators\login_page_locators.py"
#     old = "button.login-buttons"
#     new = "//button[@class='login-button floatRight']"

#     check_and_update_robot_variable_value(old, new, file_path)


#     # Closing Listener
#     # Self Healed Locators: [{'button.login-buttons': "//button[@class='login-button floatRight']"}]
#     # Replaced 'button.login-buttons' with '//button[@class="login-button floatRight"]' in C:\RFS_CI\GIT_REPO\rflx-wfm-sanity\Resources\Web\Common\Locators\login_page_locators.py
#     # Updated Locator in Variable File: C:\RFS_CI\GIT_REPO\rflx-wfm-sanity\Resources\Web\Common\Locators\login_page_locators.py at Line: [7]
