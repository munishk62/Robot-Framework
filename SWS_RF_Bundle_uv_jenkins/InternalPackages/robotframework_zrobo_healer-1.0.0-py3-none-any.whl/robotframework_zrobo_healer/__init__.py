from .healer_logger import robot_healer_logger
from .rf_listener import robotframework_zrobo_healer

__version__ = "1.0.0"

robot_healer_logger.info(f"ZRobo Healer Version: {__version__}")
