import asyncio
import json
import os
import re
import time

from robot import result, running
from robot.api import logger
from robot.api.interfaces import ListenerV3
from robot.libraries.BuiltIn import BuiltIn

from .healer import (
    analyze_locator_error_with_llm,
    get_updated_locator_from_llm,
    regenerate_updated_locator_from_llm,
)
from .healer_logger import robot_healer_logger
from .html_utils import remove_head_and_scripts
from .updater import check_and_update_robot_variable_value


def get_full_path():
    """Gets the full path of the currently executing .py file."""
    return os.path.abspath(__file__)


ERROR_MESSAGES_FILE = os.path.join(os.path.split(get_full_path())[0], "error_messages.json")
robot_healer_logger.debug(f"Error Messages File: {ERROR_MESSAGES_FILE}")


def load_error_messages():
    if os.path.exists(ERROR_MESSAGES_FILE):
        with open(ERROR_MESSAGES_FILE, "r") as file:
            return json.load(file)
    return []


def save_error_messages(error_messages):
    with open(ERROR_MESSAGES_FILE, "w") as file:
        json.dump(error_messages, file)


error_messages = load_error_messages()


class robotframework_zrobo_healer(ListenerV3):
    ROBOT_LISTENER_API_VERSION = 3

    def __init__(self):
        robot_healer_logger.info("Starting Listener")
        self.ROBOT_LIBRARY_LISTENER = self
        self.current_error_locator = None
        self.imported_resource_files = []
        self.imported_variable_files = []
        self.current_suite_file = None
        self.log_to_console = True
        self.self_healed_locators = []
        self.skip_keywords = [
            "Run Keyword And Return Status",
            "Run Keyword And Continue On Failure",
            "Run Keyword And Expect Error",
            "Run Keyword And Ignore Error",
        ]
        self.perform_healing = True
        self.keywords_healed = 0
        self.test_cases_healed = 0
        self.total_test_cases = 0
        self.passed_test_cases = 0
        self.is_test_case_healed = False
        self.locator_error_count = 0
        self.locator_error_list = []

    def log_info(self, message):
        logger.info(message, also_console=self.log_to_console)

    def log_debug(self, message):
        logger.debug(message)

    def update_robot_variable(self, variable_name, new_value):
        BuiltIn().set_suite_variable(variable_name, new_value)

    def start_suite(self, data: running.TestSuite, result: result.TestSuite):
        self.current_suite_file = str(data.source)
        self.log_info(f"Suite File: {self.current_suite_file}")
        self.locator_error_list = []

    def resource_import(self, resource: running.ResourceFile, importer: running.Import):
        self.imported_resource_files.append(str(resource.source))
        # self.log_info(f"Resource Files: {self.imported_resource_files}")

    def variables_import(self, attrs, importer: running.Import):
        variable_file_path = attrs["source"]
        self.imported_variable_files.append(variable_file_path)
        # self.log_info(f"Variable Files: {self.imported_variable_files}")

    def start_test(self, data: running.TestCase, result: result.TestCase):
        robot_healer_logger.debug(f"Starting Test")
        self.perform_healing = True
        # robot_healer_logger.debug("Performing Healing at Start Test: {}".format(self.perform_healing))

    def start_keyword(self, data: running.Keyword, result: result.Keyword):
        # robot_healer_logger.debug(f"Starting Keyword: {data.name}")
        if data.name in self.skip_keywords and self.perform_healing:
            self.perform_healing = False
        # robot_healer_logger.debug("Performing Healing at Start Keyword: {}".format(self.perform_healing))

    def end_keyword(self, data: running.Keyword, result: result.Keyword):
        if result.status == "FAIL" and self.perform_healing:
            if result.owner == "Browser":
                is_locator_error = False
                if any(re.search(pattern, result.message) for pattern in error_messages):
                    is_locator_error = True
                else:
                    is_loc_error, error_message_pattern = analyze_locator_error_with_llm(result.message, result.owner)
                    if is_loc_error == "Yes":
                        is_locator_error = True
                        error_messages.append(error_message_pattern)
                        save_error_messages(error_messages)
                if is_locator_error:
                    self.locator_error_count += 1
                    print("\n")
                    robot_healer_logger.info("Browser Library Locator not found error detected")
                    robot_healer_logger.info("Performing Self Healing")
                    robot_healer_logger.info(f"Error Message: {result.message}")
                    robot_healer_logger.debug("Captured Error Message")
                    error_message = result.message
                    if ">>>" in error_message and "iframe" in error_message:
                        robot_healer_logger.debug(f"Need to Capture Page Source from iFrame")
                        page_source = BuiltIn().run_keyword("getCompletePageWithIframes")
                    else:
                        browser_lib = BuiltIn().get_library_instance("Browser")
                        page_source = browser_lib.get_page_source()
                    page_source = remove_head_and_scripts(page_source)
                    robot_healer_logger.debug("Captured Page Source")
                    robot_healer_logger.debug("\n" + page_source + "\n")
                    for arg in data.args:
                        if arg.startswith("$") or arg.startswith("@") or arg.startswith("&"):
                            variable_value = BuiltIn().get_variable_value(arg)
                            if variable_value in str(result.message).replace("\\'", "'"):
                                self.locator_name = arg
                                break

                    start_time = time.time()
                    updated_locator, confidence_score = get_updated_locator_from_llm(
                        page_source, error_message, result.owner
                    )
                    end_time = time.time()
                    robot_healer_logger.info(f"Updated Locator: {updated_locator}")
                    robot_healer_logger.info(f"Time taken to get updated locator: {end_time - start_time:.2f} seconds")
                    robot_healer_logger.info(f"Confidence Score: {confidence_score}")

                    if updated_locator == "":
                        return
                    else:
                        is_element_present = BuiltIn().run_keyword_and_return_status(
                            "Wait For Elements State", updated_locator
                        )
                        if is_element_present and confidence_score >= 0.8:
                            pass
                        else:
                            for i in range(0, 3):
                                updated_locator, confidence_score = asyncio.run(
                                    regenerate_updated_locator_from_llm(page_source, error_message, result.owner)
                                )
                                robot_healer_logger.info(f"Error Message: {result.message}")
                                robot_healer_logger.info(f"Updated Locator: {updated_locator}")
                                robot_healer_logger.info(f"Confidence Score: {confidence_score}")
                                if updated_locator == "":
                                    return
                                else:
                                    is_element_present = BuiltIn().run_keyword_and_return_status(
                                        "Wait For Elements State", updated_locator
                                    )
                                    if is_element_present and confidence_score >= 0.85:
                                        break

                        updated_args = []
                        for variable_name in data.args:
                            if (
                                variable_name.startswith("$")
                                or variable_name.startswith("@")
                                or variable_name.startswith("&")
                            ):
                                variable_value = BuiltIn().get_variable_value(variable_name)
                                if variable_value in str(result.message).replace("\\'", "'"):
                                    self.current_error_locator = variable_value
                                    self.update_robot_variable(variable_name, updated_locator)
                                    updated_args.append(variable_name)
                                else:
                                    updated_args.append(variable_name)

                            else:
                                if variable_name in str(result.message).replace("\\'", "'"):
                                    self.current_error_locator = variable_name
                                    updated_args.append(updated_locator)
                                else:
                                    updated_args.append(variable_name)

                        is_keyword_passed = BuiltIn().run_keyword_and_return_status(data.name, *updated_args)

                        if is_keyword_passed:
                            robot_healer_logger.info("Self Healing Successful")
                            result.status = "PASS"
                            self.keywords_healed += 1
                            result.tags.add("self_healed")
                            self.is_test_case_healed = True
                            self.self_healed_locators.append({self.current_error_locator: updated_locator})
                        # else:
                        #     print("Self Healing Unsuccessful")

            elif result.owner == "AppiumLibrary":
                is_locator_error = False
                if any(re.search(pattern, result.message) for pattern in error_messages):
                    is_locator_error = True
                else:
                    is_loc_error, error_message_pattern = analyze_locator_error_with_llm(result.message, result.owner)
                    if is_loc_error == "Yes":
                        is_locator_error = True
                        error_messages.append(error_message_pattern)
                        save_error_messages(error_messages)

                if is_locator_error:
                    if result.message in self.locator_error_list:
                        pass
                    else:
                        self.locator_error_list.append(result.message)
                        self.locator_error_count += 1
                    robot_healer_logger.info("Appium Library Locator not found error detected")
                    robot_healer_logger.info("Performing Self Healing")
                    robot_healer_logger.info(f"Error Message: {result.message}")
                    robot_healer_logger.debug("Captured Error Message")
                    error_message = result.message
                    appium_lib = BuiltIn().get_library_instance("AppiumLibrary")
                    page_source = appium_lib.get_source()

                    for arg in data.args:
                        if arg.startswith("$") or arg.startswith("@") or arg.startswith("&"):
                            variable_value = BuiltIn().get_variable_value(arg)
                            if variable_value in str(result.message).replace("\\'", "'"):
                                self.locator_name = arg
                                break

                    start_time = time.time()
                    updated_locator, confidence_score = get_updated_locator_from_llm(
                        page_source, error_message, result.owner
                    )
                    end_time = time.time()
                    robot_healer_logger.info(f"Updated Locator: {updated_locator}")
                    robot_healer_logger.info(f"Time taken to get updated locator: {end_time - start_time:.2f} seconds")
                    robot_healer_logger.info(f"Confidence Score: {confidence_score}")

                    if updated_locator == "":
                        return
                    else:
                        is_element_present = BuiltIn().run_keyword_and_return_status(
                            "Wait Until Element Is Visible", updated_locator
                        )
                        if is_element_present and confidence_score >= 0.85:
                            pass
                        else:
                            for i in range(0, 3):
                                updated_locator, confidence_score = asyncio.run(
                                    regenerate_updated_locator_from_llm(page_source, error_message, result.owner)
                                )
                                robot_healer_logger.info(f"Error Message: {result.message}")
                                self.log_info(f"Updated Locator: {updated_locator}")
                                self.log_info(f"Confidence Score: {confidence_score}")
                                if updated_locator == "":
                                    return
                                else:
                                    is_element_present = BuiltIn().run_keyword_and_return_status(
                                        "Wait Until Element Is Visible", updated_locator
                                    )
                                    if is_element_present and confidence_score >= 0.85:
                                        break

                        updated_args = []
                        for variable_name in data.args:
                            if (
                                variable_name.startswith("$")
                                or variable_name.startswith("@")
                                or variable_name.startswith("&")
                            ):
                                variable_value = BuiltIn().get_variable_value(variable_name)
                                if variable_value in str(result.message).replace("\\'", "'"):
                                    self.current_error_locator = variable_value
                                    self.update_robot_variable(variable_name, updated_locator)
                                    updated_args.append(variable_name)
                                else:
                                    updated_args.append(variable_name)

                            else:
                                if variable_name in str(result.message).replace("\\'", "'"):
                                    self.current_error_locator = variable_name
                                    updated_args.append(updated_locator)
                                else:
                                    updated_args.append(variable_name)

                        is_keyword_passed = BuiltIn().run_keyword_and_return_status(data.name, *updated_args)
                        if is_keyword_passed:
                            self.log_info("Self Healing Successful")
                            result.status = "PASS"
                            self.keywords_healed += 1
                            result.tags.add("self_healed")
                            self.is_test_case_healed = True
                            self.self_healed_locators.append({self.current_error_locator: updated_locator})
                        else:
                            print("Keyword not passed")

        # robot_healer_logger.debug(f"Ending Keyword: {data.name}")
        if data.name in self.skip_keywords and (not self.perform_healing):
            self.perform_healing = True
        # robot_healer_logger.debug("Performing Healing at End Keyword: {}".format(self.perform_healing))

    def end_test(self, data: running.TestCase, result: result.TestCase):
        # self.log_info(f"Ending Test")
        self.total_test_cases += 1
        if result.status == "PASS":
            self.passed_test_cases += 1
            if self.is_test_case_healed:
                self.test_cases_healed += 1
                self.is_test_case_healed = False

    def end_suite(self, data: running.TestSuite, result: result.TestSuite):
        self.log_info(f"Ending Suite")

    def close(self):
        # self.log_info(f"Closing Listener")
        robot_healer_logger.info(f"Self Healed Locators")
        for locator in self.self_healed_locators:
            for original, healed in locator.items():
                robot_healer_logger.info(f"'{original}' -> '{healed}'")

        robot_healer_logger.debug("Updating Locator in Resource Files")

        for resource_file in self.imported_resource_files:
            for locator in self.self_healed_locators:
                for old_locator, updated_locator in locator.items():
                    try:
                        is_updated, line_no = check_and_update_robot_variable_value(
                            old_locator, updated_locator, resource_file
                        )
                        if is_updated:
                            robot_healer_logger.info(
                                f"Updated Locator in \n\t Resource File: {resource_file} \n\t Line: {line_no}"
                            )
                    except Exception as e:
                        robot_healer_logger.error(f"Error while updating Resource Files: {resource_file}")
                        robot_healer_logger.debug(f"Error: {e}", exc_info=True)
        robot_healer_logger.debug("Updating Locator in Variable Files")

        for variable_file in self.imported_variable_files:
            robot_healer_logger.debug(f"Variable File: {variable_file}")
            for locator in self.self_healed_locators:
                for old_locator, updated_locator in locator.items():
                    try:
                        is_updated, line_no = check_and_update_robot_variable_value(
                            old_locator, updated_locator, variable_file
                        )
                        if is_updated:
                            robot_healer_logger.info(
                                f"Updated Locator in \n\t Variable File: {variable_file} \n\t Line: {line_no}"
                            )
                    except Exception as e:
                        robot_healer_logger.error(f"Error while updating Variable Files: {variable_file}")
                        robot_healer_logger.debug(f"Error : {e}", exc_info=True)

        robot_healer_logger.debug("Updating Locator in Suite File")

        for locator in self.self_healed_locators:
            robot_healer_logger.debug(f"Suite File: {self.current_suite_file}")
            for old_locator, updated_locator in locator.items():
                try:
                    is_updated, line_no = check_and_update_robot_variable_value(
                        old_locator, updated_locator, self.current_suite_file
                    )
                    if is_updated:
                        robot_healer_logger.info(
                            f"Updated Locator in \n\t Suite File: {self.current_suite_file} \n\t Line: {line_no}"
                        )
                except Exception as e:
                    robot_healer_logger.error(f"Error while updating Suite File: {self.current_suite_file}")
                    robot_healer_logger.debug(f"Error : {e}", exc_info=True)

        healing_percentage = (
            (self.keywords_healed / self.locator_error_count) * 100 if self.locator_error_count > 0 else 0
        )
        pass_percentage = (self.passed_test_cases / self.total_test_cases) * 100 if self.total_test_cases > 0 else 0
        pass_percentage_without_healing = (
            (((self.passed_test_cases - self.test_cases_healed) / self.total_test_cases) * 100)
            if self.total_test_cases > 0
            else 0
        )
        robot_healer_logger.info("------------------------------------------------------------------------------")
        robot_healer_logger.info(f"Total Unique Locator Errors Detected    : {self.locator_error_count}")
        robot_healer_logger.info(f"Total Locators Healed                   : {self.keywords_healed}")
        robot_healer_logger.info(f"Percentage of Locator Errors Healed     : {healing_percentage:.2f}%")
        robot_healer_logger.info(f"Total Test Cases Healed                 : {self.test_cases_healed}")
        robot_healer_logger.info("------------------------------------------------------------------------------")
        robot_healer_logger.info(f"Total Test Cases                        : {self.total_test_cases}")
        robot_healer_logger.info(
            f"Total Test Cases Passed Without Healing : {self.passed_test_cases - self.test_cases_healed}"
        )
        robot_healer_logger.info(f"Total Test Cases Passed With Healing    : {self.passed_test_cases}")
        robot_healer_logger.info("------------------------------------------------------------------------------")
        robot_healer_logger.info(f"Pass Percentage Without Healing         : {pass_percentage_without_healing:.2f}%")
        robot_healer_logger.info(f"Pass Percentage With Healing            : {pass_percentage:.2f}%")
        robot_healer_logger.info("------------------------------------------------------------------------------")
        robot_healer_logger.info("Execution Completed")
