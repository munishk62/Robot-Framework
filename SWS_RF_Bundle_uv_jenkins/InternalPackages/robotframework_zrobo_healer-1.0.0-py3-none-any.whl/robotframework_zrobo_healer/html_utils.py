from bs4 import BeautifulSoup


def remove_head_and_scripts(html_content):
    # Count the number of characters in the original HTML content
    original_length = len(html_content)
    # print(f"Original HTML character count: {original_length}")

    # Parse the HTML content using BeautifulSoup
    soup = BeautifulSoup(html_content, "html.parser")

    # Remove the <head> tag
    head_tag = soup.head
    if head_tag:
        head_tag.decompose()

    # Remove all <script> tags within the <body>
    for script in soup.body.find_all("script"):
        script.decompose()

    # Convert the modified HTML back to a string
    modified_html_content = str(soup)

    # Count the number of characters in the modified HTML content
    modified_length = len(modified_html_content)
    # print(f"Modified HTML character count: {modified_length}")
    # print(modified_html_content)
    return modified_html_content
