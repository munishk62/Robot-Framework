import os

from dotenv import load_dotenv
from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.output_parsers.json import JsonOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import AzureChatOpenAI

from .healer_logger import robot_healer_logger
from .prompts import prompts

# from langchain_google_vertexai import ChatVertexAI


load_dotenv()
robot_healer_logger.info("Loading LLM Model...")

llm_model_name = "gpt-4o"
API_VERSION = "2024-06-01"
llm_azure = AzureChatOpenAI(
    azure_endpoint=os.getenv("GPT_4o_ENDPOINT"),
    openai_api_version=API_VERSION,
    openai_api_key=os.getenv("GPT_4o_API_KEY"),
    azure_deployment=llm_model_name,
    model_name=llm_model_name,
    streaming=True,
)

# llm_gemini = ChatVertexAI(
#     model="gemini-1.5-flash-002",
#     temperature=0,
# )

robot_healer_logger.info("Loaded LLM Models")
parser = JsonOutputParser()
chat_history = InMemoryChatMessageHistory()

browser_prompt = ChatPromptTemplate.from_messages(prompts["browser_prompt"])

appium_prompt = ChatPromptTemplate.from_messages(prompts["appium_prompt"])

retry_browser_prompt = ChatPromptTemplate.from_messages(prompts["retry_browser_prompt"])

retry_appium_prompt = ChatPromptTemplate.from_messages(prompts["retry_appium_prompt"])

appium_error_prompt = ChatPromptTemplate.from_messages(prompts["appium_error_prompt"])

browser_error_prompt = ChatPromptTemplate.from_messages(prompts["browser_error_prompt"])


def test_llm():
    messages = [
        (
            "system",
            "You are a helpful assistant that translates English to French. Translate the user sentence.",
        ),
        ("human", "I love programming."),
    ]
    ai_msg = llm_azure.invoke(messages)
    print(ai_msg)


def get_updated_locator_from_llm(page_source, error_message, library_name):
    # """Get the updated locator from the Locator Learning Model."""
    # # This is a placeholder function. Replace this with the actual implementation.
    # # return "id=user-name"
    # return "id=com.google.android.calculator:id/digit_8"

    chat_history.clear()

    if library_name == "Browser":
        llm_chain = browser_prompt | llm_azure | parser
        response = llm_chain.invoke({"error_message": error_message, "page_source": page_source})
        robot_healer_logger.debug(response)
        chat_history.add_user_message(
            browser_prompt.messages[1].prompt.template.format(error_message=error_message, page_source=page_source)
        )
        chat_history.add_ai_message(str(response))

    elif library_name == "AppiumLibrary":
        llm_chain = appium_prompt | llm_azure | parser
        response = llm_chain.invoke({"error_message": error_message, "page_source": page_source})
        chat_history.add_user_message(
            appium_prompt.messages[1].prompt.template.format(error_message=error_message, page_source=page_source)
        )
        chat_history.add_ai_message(str(response))

    else:
        return "Invalid error source. Please specify either 'Browser' or 'Appium'."

    return response["updated_ui_locator"], response["confidence_score"]


async def regenerate_updated_locator_from_llm(page_source, error_message, library_name):
    if library_name == "Browser":
        llm_chain = retry_browser_prompt | llm_azure | parser
        response = llm_chain.invoke(
            {"error_message": error_message, "page_source": page_source, "history": await chat_history.aget_messages()}
        )
        chat_history.add_user_message(
            retry_browser_prompt.messages[1].prompt.template.format(
                error_message=error_message, page_source=page_source
            )
        )
        chat_history.add_ai_message(str(response))

    elif library_name == "AppiumLibrary":
        llm_chain = retry_appium_prompt | llm_azure | parser
        response = llm_chain.invoke(
            {"error_message": error_message, "page_source": page_source, "history": await chat_history.aget_messages()}
        )
        chat_history.add_user_message(
            retry_appium_prompt.messages[1].prompt.template.format(error_message=error_message, page_source=page_source)
        )
        chat_history.add_ai_message(str(response))

    else:
        return "Invalid error source. Please specify either 'Browser' or 'Appium'."

    return response["updated_ui_locator"], response["confidence_score"]


def analyze_locator_error_with_llm(error_message, library_name):
    if library_name == "AppiumLibrary":
        llm_chain = appium_error_prompt | llm_azure | parser
        response = llm_chain.invoke(
            {
                "error_message": error_message,
            }
        )

    elif library_name == "Browser":
        llm_chain = browser_error_prompt | llm_azure | parser
        response = llm_chain.invoke(
            {
                "error_message": error_message,
            }
        )

    else:
        return "No", ""

    return response["is_locator_error"], response["error_message_pattern"]
